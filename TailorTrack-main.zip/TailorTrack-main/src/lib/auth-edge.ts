export const ADMIN_USERNAME = "Admin";
export const ADMIN_PASSWORD = "rgadmin";
const SECRET = "tailortracker-secret-key-2024";

export async function createSessionToken(): Promise<string> {
  const payload = `${ADMIN_USERNAME}:${Date.now()}`;
  const encoder = new TextEncoder();
  const keyData = encoder.encode(SECRET);
  const key = await crypto.subtle.importKey(
    "raw",
    keyData,
    { name: "HMAC", hash: "SHA-256" },
    false,
    ["sign"]
  );
  const signature = await crypto.subtle.sign(
    "HMAC",
    key,
    encoder.encode(payload)
  );
  const sigHex = Array.from(new Uint8Array(signature))
    .map((b) => b.toString(16).padStart(2, "0"))
    .join("");
  return btoa(`${payload}:${sigHex}`);
}

export async function verifySessionToken(token: string): Promise<boolean> {
  try {
    const decoded = atob(token);
    const lastColon = decoded.lastIndexOf(":");
    if (lastColon === -1) return false;
    const payload = decoded.substring(0, lastColon);
    const sigHex = decoded.substring(lastColon + 1);

    const encoder = new TextEncoder();
    const keyData = encoder.encode(SECRET);
    const key = await crypto.subtle.importKey(
      "raw",
      keyData,
      { name: "HMAC", hash: "SHA-256" },
      false,
      ["verify"]
    );
    const hexPairs = sigHex.match(/.{2}/g);
    if (!hexPairs) return false;
    const sigBytes = new Uint8Array(hexPairs.map((b) => parseInt(b, 16)));
    return await crypto.subtle.verify(
      "HMAC",
      key,
      sigBytes,
      encoder.encode(payload)
    );
  } catch {
    return false;
  }
}
