"use client";

export type OrderStatus = "Pending" | "In Progress" | "Completed" | "Delivered";

export interface Customer {
  id: string;
  name: string;
  email: string;
  phone: string;
  address: string;
  notes: string;
  lastVisit: string;
  measurements: {
    chest: string;
    waist: string;
    sleeve: string;
    shoulder: string;
    inseam: string;
  };
}

export interface Order {
  id: string;
  customerId: string;
  orderNo: string;
  service: string;
  quantity: string;
  price: string;
  status: OrderStatus;
  createdAt: string;
  deliveryDate: string;
  trialDate: string;
  note: string;
  // Upper body measurement fields
  measurementLength: string;
  measurementBody1: string;
  measurementBody2: string;
  measurementBody3: string;
  measurementShoulder: string;
  measurementSleeves: string;
  measurementCuff: string;
  measurementCollar: string;
  measurementFront1: string;
  measurementFront2: string;
  measurementFront3: string;
  measurementBack1: string;
  measurementBack2: string;
  measurementBack3: string;
  measurementBiceps: string;
  measurementRadius: string;
  // Pants measurement fields
  pantLength: string;
  pantWaist: string;
  pantHip: string;
  pantThigh: string;
  pantMiddle1: string;
  pantMiddle2: string;
  pantQuarter: string;
  pantBottom: string;
  pantHigh: string;
  pantFront: string;
  pantBack: string;
}

export interface Appointment {
  id: string;
  time: string;
  customer: string;
  service: string;
  type: string;
  date: string;
}

export const GARMENT_TYPES = [
  "Shirt",
  "Coat",
  "Waist Coat",
  "Overcoat",
  "Mujib Coat",
  "Prince Coat",
  "Sherwani",
  "Panjabi",
  "Sodria",
  "Tub",
  "Fotua",
  "Katua",
  "Safari",
  "Kabuli",
  "Apron",
  "Pant",
  "Gabardine",
  "Jeans",
  "Payjama",
  "3 quarter",
];

export const initialCustomers: Customer[] = [];

export const initialOrders: Order[] = [];

export const initialAppointments: Appointment[] = [
  {
    id: "APT-001",
    time: "10:30 AM",
    customer: "Michael Ross",
    service: "Dress Hemming",
    type: "Final Fitting",
    date: "Today",
  },
  {
    id: "APT-002",
    time: "02:00 PM",
    customer: "Harvey Specter",
    service: "Custom Shirt",
    type: "Pick-up",
    date: "Today",
  },
  {
    id: "APT-003",
    time: "04:15 PM",
    customer: "Louis Litt",
    service: "Suit Repair",
    type: "Consultation",
    date: "Today",
  },
  {
    id: "APT-004",
    time: "11:00 AM",
    customer: "Sarah Jenkins",
    service: "Bespoke Suit",
    type: "Initial Measurement",
    date: "Tomorrow",
  },
  {
    id: "APT-005",
    time: "03:30 PM",
    customer: "Harvey Specter",
    service: "Bespoke Suit",
    type: "Final Fitting",
    date: "Tomorrow",
  },
];
