"use client";

import {
  createContext,
  useContext,
  useState,
  useEffect,
  useCallback,
  ReactNode,
} from "react";
import { Customer, Order, Appointment } from "./store";

interface AppContextType {
  customers: Customer[];
  orders: Order[];
  appointments: Appointment[];
  loading: boolean;
  isAdmin: boolean;
  login: (username: string, password: string) => Promise<boolean>;
  logout: () => Promise<void>;
  addCustomer: (customer: Omit<Customer, "id">) => Promise<void>;
  updateCustomer: (id: string, customer: Partial<Customer>) => Promise<void>;
  deleteCustomer: (id: string) => Promise<void>;
  addOrder: (order: Omit<Order, "id" | "createdAt">) => Promise<void>;
  updateOrder: (id: string, order: Partial<Order>) => Promise<void>;
  deleteOrder: (id: string) => Promise<void>;
  addAppointment: (appointment: Omit<Appointment, "id">) => Promise<void>;
  deleteAppointment: (id: string) => Promise<void>;
}

const AppContext = createContext<AppContextType | null>(null);

export function AppProvider({ children }: { children: ReactNode }) {
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [orders, setOrders] = useState<Order[]>([]);
  const [appointments, setAppointments] = useState<Appointment[]>([]);
  const [loading, setLoading] = useState(true);
  const [isAdmin, setIsAdmin] = useState(false);

  // Check auth status on mount
  const checkAuth = useCallback(async () => {
    try {
      const res = await fetch("/api/auth/me");
      const data = await res.json();
      setIsAdmin(data.isAdmin === true);
    } catch {
      setIsAdmin(false);
    }
  }, []);

  // Load all data on mount
  const loadData = useCallback(async () => {
    setLoading(true);
    try {
      const [customersRes, ordersRes, appointmentsRes] = await Promise.all([
        fetch("/api/customers"),
        fetch("/api/orders"),
        fetch("/api/appointments"),
      ]);
      const [customersData, ordersData, appointmentsData] = await Promise.all([
        customersRes.json(),
        ordersRes.json(),
        appointmentsRes.json(),
      ]);
      setCustomers(Array.isArray(customersData) ? customersData : []);
      setOrders(Array.isArray(ordersData) ? ordersData : []);
      setAppointments(Array.isArray(appointmentsData) ? appointmentsData : []);
    } catch (err) {
      console.error("Failed to load data:", err);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    checkAuth();
    loadData();
  }, [checkAuth, loadData]);

  const login = async (username: string, password: string): Promise<boolean> => {
    try {
      const res = await fetch("/api/auth/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ username, password }),
      });
      if (res.ok) {
        setIsAdmin(true);
        return true;
      }
      return false;
    } catch {
      return false;
    }
  };

  const logout = async (): Promise<void> => {
    try {
      await fetch("/api/auth/logout", { method: "POST" });
      setIsAdmin(false);
    } catch {
      setIsAdmin(false);
    }
  };

  const addCustomer = async (customer: Omit<Customer, "id">) => {
    const res = await fetch("/api/customers", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(customer),
    });
    const { id } = await res.json();
    const newCustomer: Customer = { ...customer, id };
    setCustomers((prev) => [...prev, newCustomer]);
  };

  const updateCustomer = async (id: string, updates: Partial<Customer>) => {
    await fetch(`/api/customers?id=${id}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(updates),
    });
    setCustomers((prev) =>
      prev.map((c) => (c.id === id ? { ...c, ...updates } : c))
    );
  };

  const deleteCustomer = async (id: string) => {
    await fetch(`/api/customers?id=${id}`, { method: "DELETE" });
    setCustomers((prev) => prev.filter((c) => c.id !== id));
  };

  const addOrder = async (order: Omit<Order, "id" | "createdAt">) => {
    const res = await fetch("/api/orders", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(order),
    });
    const { id, createdAt } = await res.json();
    const newOrder: Order = { ...order, id, createdAt };
    setOrders((prev) => [...prev, newOrder]);
  };

  const updateOrder = async (id: string, updates: Partial<Order>) => {
    await fetch(`/api/orders?id=${id}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(updates),
    });
    setOrders((prev) =>
      prev.map((o) => (o.id === id ? { ...o, ...updates } : o))
    );
  };

  const deleteOrder = async (id: string) => {
    await fetch(`/api/orders?id=${id}`, { method: "DELETE" });
    setOrders((prev) => prev.filter((o) => o.id !== id));
  };

  const addAppointment = async (appointment: Omit<Appointment, "id">) => {
    const res = await fetch("/api/appointments", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(appointment),
    });
    const { id } = await res.json();
    const newAppointment: Appointment = { ...appointment, id };
    setAppointments((prev) => [...prev, newAppointment]);
  };

  const deleteAppointment = async (id: string) => {
    await fetch(`/api/appointments?id=${id}`, { method: "DELETE" });
    setAppointments((prev) => prev.filter((a) => a.id !== id));
  };

  return (
    <AppContext.Provider
      value={{
        customers,
        orders,
        appointments,
        loading,
        isAdmin,
        login,
        logout,
        addCustomer,
        updateCustomer,
        deleteCustomer,
        addOrder,
        updateOrder,
        deleteOrder,
        addAppointment,
        deleteAppointment,
      }}
    >
      {children}
    </AppContext.Provider>
  );
}

export function useApp() {
  const ctx = useContext(AppContext);
  if (!ctx) throw new Error("useApp must be used within AppProvider");
  return ctx;
}
