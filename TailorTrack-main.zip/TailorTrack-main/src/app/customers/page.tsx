"use client";

import { useState } from "react";
import { Suspense } from "react";
import { useApp } from "@/lib/context";
import { Customer } from "@/lib/store";
import { Plus, Search, Trash2, X, ChevronRight, Ruler, Printer, Pencil, Save } from "lucide-react";
import { Order } from "@/lib/store";
import { useRouter, useSearchParams } from "next/navigation";

type CustomerForm = Omit<Customer, "id">;

const emptyForm: CustomerForm = {
  name: "",
  email: "",
  phone: "",
  address: "",
  notes: "",
  lastVisit: new Date().toISOString().split("T")[0],
  measurements: {
    chest: "",
    waist: "",
    sleeve: "",
    shoulder: "",
    inseam: "",
  },
};

function CustomersContent() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const { customers, orders, addCustomer, updateCustomer, deleteCustomer, updateOrder, isAdmin } =
    useApp();
  const [search, setSearch] = useState("");
  const [selected, setSelected] = useState<Customer | null>(null);
  const [showAddModal, setShowAddModal] = useState(false);
  const [showEditModal, setShowEditModal] = useState(false);
  const [showMeasurementsModal, setShowMeasurementsModal] = useState(false);
  const [selectedOrder, setSelectedOrder] = useState<Order | null>(null);
  const [showEditMeasurementsModal, setShowEditMeasurementsModal] = useState(false);
  const [editOrderMeasurements, setEditOrderMeasurements] = useState<Record<string, string>>({});
  const [form, setForm] = useState<CustomerForm>(emptyForm);
  const [measurements, setMeasurements] = useState({
    chest: "",
    waist: "",
    sleeve: "",
    shoulder: "",
    inseam: "",
  });

  const filtered = customers.filter((c) => {
    const q = search.toLowerCase();
    return (
      c.name.toLowerCase().includes(q) ||
      c.email.toLowerCase().includes(q) ||
      c.phone.toLowerCase().includes(q)
    );
  });

  const handleAddSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.name) return;
    addCustomer(form);
    setForm(emptyForm);
    setShowAddModal(false);
  };

  const handleEditSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selected) return;
    updateCustomer(selected.id, form);
    setShowEditModal(false);
  };

  const handleSaveMeasurements = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selected) return;
    updateCustomer(selected.id, { measurements });
    setSelected({ ...selected, measurements });
    setShowMeasurementsModal(false);
  };

  const openEditOrderMeasurements = (order: Order) => {
    setEditOrderMeasurements({
      measurementLength: order.measurementLength || '',
      measurementBody1: order.measurementBody1 || '',
      measurementBody2: order.measurementBody2 || '',
      measurementBody3: order.measurementBody3 || '',
      measurementShoulder: order.measurementShoulder || '',
      measurementSleeves: order.measurementSleeves || '',
      measurementCuff: order.measurementCuff || '',
      measurementCollar: order.measurementCollar || '',
      measurementFront1: order.measurementFront1 || '',
      measurementFront2: order.measurementFront2 || '',
      measurementFront3: order.measurementFront3 || '',
      measurementBack1: order.measurementBack1 || '',
      measurementBack2: order.measurementBack2 || '',
      measurementBack3: order.measurementBack3 || '',
      measurementBiceps: order.measurementBiceps || '',
      measurementRadius: order.measurementRadius || '',
      pantLength: order.pantLength || '',
      pantWaist: order.pantWaist || '',
      pantHip: order.pantHip || '',
      pantThigh: order.pantThigh || '',
      pantMiddle1: order.pantMiddle1 || '',
      pantMiddle2: order.pantMiddle2 || '',
      pantQuarter: order.pantQuarter || '',
      pantBottom: order.pantBottom || '',
      pantHigh: order.pantHigh || '',
      pantFront: order.pantFront || '',
      pantBack: order.pantBack || '',
    });
    setSelectedOrder(order);
    setShowEditMeasurementsModal(true);
  };

  const handleSaveOrderMeasurements = async () => {
    if (!selectedOrder) return;
    await updateOrder(selectedOrder.id, editOrderMeasurements);
    setSelectedOrder({ ...selectedOrder, ...editOrderMeasurements });
    setShowEditMeasurementsModal(false);
  };

  const openEdit = (customer: Customer) => {
    setSelected(customer);
    setForm({
      name: customer.name,
      email: customer.email,
      phone: customer.phone,
      address: customer.address,
      notes: customer.notes,
      lastVisit: customer.lastVisit,
      measurements: customer.measurements,
    });
    setShowEditModal(true);
  };

  const openMeasurements = (customer: Customer) => {
    setSelected(customer);
    setMeasurements(customer.measurements);
    setShowMeasurementsModal(true);
  };

  const getCustomerOrders = (customerId: string) =>
    orders.filter((o) => o.customerId === customerId);

  const getOrderMeasurements = (order: Order) => {
    return {
      // Upper body measurements organized by position
      length: order.measurementLength || '',
      chest: order.measurementBody1 || '',
      waist: order.measurementBody2 || '',
      bottom: order.measurementBody3 || '',
      shoulder: order.measurementShoulder || '',
      sleeves: order.measurementSleeves || '',
      collar: order.measurementCollar || '',
      cuff: order.measurementCuff || '',
      biceps: order.measurementBiceps || '',
      radius: order.measurementRadius || '',
      front1: order.measurementFront1 || '',
      front2: order.measurementFront2 || '',
      front3: order.measurementFront3 || '',
      back1: order.measurementBack1 || '',
      back2: order.measurementBack2 || '',
      back3: order.measurementBack3 || '',
      // Pants measurements
      pantLength: order.pantLength || '',
      pantWaist: order.pantWaist || '',
      pantHip: order.pantHip || '',
      pantThigh: order.pantThigh || '',
      pantMiddle1: order.pantMiddle1 || '',
      pantMiddle2: order.pantMiddle2 || '',
      pantQuarter: order.pantQuarter || '',
      pantBottom: order.pantBottom || '',
      pantHigh: order.pantHigh || '',
      pantFront: order.pantFront || '',
      pantBack: order.pantBack || '',
    };
  };

  const hasUpperBodyMeasurements = (m: ReturnType<typeof getOrderMeasurements>) => {
    return m.length || m.chest || m.waist || m.bottom || m.shoulder || m.sleeves || m.collar || m.cuff || m.biceps;
  };

  const hasPantsMeasurements = (m: ReturnType<typeof getOrderMeasurements>) => {
    return m.pantLength || m.pantWaist || m.pantHip || m.pantThigh || m.pantMiddle1 || m.pantMiddle2 || m.pantQuarter || m.pantBottom || m.pantHigh || m.pantFront || m.pantBack;
  };

  const handlePrint = (order: Order) => {
    const printWindow = window.open('', '_blank');
    if (!printWindow) return;
    
    const customer = customers.find(c => c.id === order.customerId);
    const m = getOrderMeasurements(order);
    
    const printContent = `
      <!DOCTYPE html>
      <html>
      <head>
        <title>Order Details - ${order.service}</title>
        <style>
          body { font-family: Arial, sans-serif; padding: 20px; max-width: 800px; margin: 0 auto; }
          h1 { color: #333; border-bottom: 2px solid #4f46e5; padding-bottom: 10px; }
          h2 { color: #666; margin-top: 20px; }
          .info-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 10px; margin-bottom: 20px; }
          .info-item { background: #f3f4f6; padding: 10px; border-radius: 5px; }
          .info-label { font-size: 12px; color: #666; }
          .info-value { font-size: 16px; font-weight: bold; color: #333; }
          .status { display: inline-block; padding: 5px 10px; border-radius: 20px; font-size: 12px; font-weight: bold; }
          .status-pending { background: #fef3c7; color: #d97706; }
          .status-progress { background: #dbeafe; color: #2563eb; }
          .status-completed { background: #d1fae5; color: #059669; }
          .no-print { margin-top: 20px; }
          @media print { .no-print { display: none; } }
          
          /* Custom measurement layout */
          .measurements-table { width: 100%; border-collapse: collapse; }
          .measurements-table td { padding: 8px; text-align: center; border: 1px solid #e5e7eb; }
          .measurements-table .measurement-value { font-size: 18px; font-weight: bold; color: #4f46e5; }
          .measurements-table .measurement-label { font-size: 12px; color: #666; }
          .measurements-table .empty-cell { background: #f9fafb; }
          .measurements-table .section-header { background: #e0e7ff; font-weight: bold; color: #4f46e5; }
        </style>
      </head>
      <body>
        <h1>TailorTracker - Order Details</h1>
        
        <h2>Customer Information</h2>
        <div class="info-grid">
          <div class="info-item">
            <div class="info-label">Name</div>
            <div class="info-value">${customer?.name || 'N/A'}</div>
          </div>
          <div class="info-item">
            <div class="info-label">Phone</div>
            <div class="info-value">${customer?.phone || 'N/A'}</div>
          </div>
          <div class="info-item">
            <div class="info-label">Email</div>
            <div class="info-value">${customer?.email || 'N/A'}</div>
          </div>
          <div class="info-item">
            <div class="info-label">Address</div>
            <div class="info-value">${customer?.address || 'N/A'}</div>
          </div>
        </div>
        
        <h2>Order Information</h2>
        <div class="info-grid">
          <div class="info-item">
            <div class="info-label">Order ID</div>
            <div class="info-value">${order.orderNo || order.id}</div>
          </div>
          <div class="info-item">
            <div class="info-label">Service</div>
            <div class="info-value">${order.service}</div>
          </div>
          <div class="info-item">
            <div class="info-label">Quantity</div>
            <div class="info-value">${order.quantity || '1'}</div>
          </div>
          <div class="info-item">
            <div class="info-label">Price</div>
            <div class="info-value">${order.price}</div>
          </div>
          <div class="info-item">
            <div class="info-label">Status</div>
            <div class="info-value"><span class="status ${order.status === 'Completed' ? 'status-completed' : order.status === 'In Progress' ? 'status-progress' : 'status-pending'}">${order.status}</span></div>
          </div>
          <div class="info-item">
            <div class="info-label">Order Date</div>
            <div class="info-value">${order.createdAt}</div>
          </div>
          <div class="info-item">
            <div class="info-label">Delivery Date</div>
            <div class="info-value">${order.deliveryDate || 'N/A'}</div>
          </div>
          <div class="info-item">
            <div class="info-label">Trial Date</div>
            <div class="info-value">${order.trialDate || 'N/A'}</div>
          </div>
        </div>
        
        ${order.note ? `<div class="info-item" style="grid-column: 1 / -1;">
          <div class="info-label">Note</div>
          <div class="info-value">${order.note}</div>
        </div>` : ''}
        
        ${hasUpperBodyMeasurements(m) ? `
        <h2>Measurements</h2>
        <table class="measurements-table">
          <tr>
            <td>${m.length ? '<div class="measurement-value">' + m.length + '</div><div class="measurement-label">Length</div>' : '<span class="empty-cell"></span>'}</td>
            <td>${m.chest ? '<div class="measurement-value">' + m.chest + '</div><div class="measurement-label">Chest</div>' : '<span class="empty-cell"></span>'}</td>
            <td>${m.shoulder ? '<div class="measurement-value">' + m.shoulder + '</div><div class="measurement-label">Shoulder</div>' : '<span class="empty-cell"></span>'}</td>
            <td>${m.sleeves ? '<div class="measurement-value">' + m.sleeves + '</div><div class="measurement-label">Sleeves</div>' : '<span class="empty-cell"></span>'}</td>
            <td>${m.collar ? '<div class="measurement-value">' + m.collar + '</div><div class="measurement-label">Collar</div>' : '<span class="empty-cell"></span>'}</td>
            <td><div style="display: flex; gap: 5px;"><div style="flex: 1;">${m.front1 ? '<div class="measurement-value">' + m.front1 + '</div><div class="measurement-label">Front (1)</div>' : ''}</div><div style="flex: 1;">${m.back1 ? '<div class="measurement-value">' + m.back1 + '</div><div class="measurement-label">Back (1)</div>' : ''}</div></div></td>
          </tr>
          <tr>
            <td></td>
            <td>${m.waist ? '<div class="measurement-value">' + m.waist + '</div><div class="measurement-label">Waist</div>' : '<span class="empty-cell"></span>'}</td>
            <td></td>
            <td>${m.cuff ? '<div class="measurement-value">' + m.cuff + '</div><div class="measurement-label">Cuff</div>' : '<span class="empty-cell"></span>'}</td>
            <td></td>
            <td><div style="display: flex; gap: 5px;"><div style="flex: 1;">${m.front2 ? '<div class="measurement-value">' + m.front2 + '</div><div class="measurement-label">Front (2)</div>' : ''}</div><div style="flex: 1;">${m.back2 ? '<div class="measurement-value">' + m.back2 + '</div><div class="measurement-label">Back (2)</div>' : ''}</div></div></td>
          </tr>
          <tr>
            <td></td>
            <td>${m.bottom ? '<div class="measurement-value">' + m.bottom + '</div><div class="measurement-label">Bottom</div>' : '<span class="empty-cell"></span>'}</td>
            <td></td>
            <td></td>
            <td></td>
            <td><div style="display: flex; gap: 5px;"><div style="flex: 1;">${m.front3 ? '<div class="measurement-value">' + m.front3 + '</div><div class="measurement-label">Front (3)</div>' : ''}</div><div style="flex: 1;">${m.back3 ? '<div class="measurement-value">' + m.back3 + '</div><div class="measurement-label">Back (3)</div>' : ''}</div></div></td>
          </tr>
          <tr>
            <td>${m.biceps ? '<div class="measurement-value">' + m.biceps + '</div><div class="measurement-label">Biceps (M)</div>' : '<span class="empty-cell"></span>'}</td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
          </tr>
          <tr>
            <td>${m.radius ? '<div class="measurement-value">' + m.radius + '</div><div class="measurement-label">Radius (M)</div>' : '<span class="empty-cell"></span>'}</td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
          </tr>
        </table>
        ` : ''}
        
        ${hasPantsMeasurements(m) ? `
        <h2>Pants Measurements</h2>
        <table class="measurements-table">
          <tr>
            <td>${m.pantLength ? '<div class="measurement-value">' + m.pantLength + '</div><div class="measurement-label">Length</div>' : '<span class="empty-cell"></span>'}</td>
            <td>${m.pantWaist ? '<div class="measurement-value">' + m.pantWaist + '</div><div class="measurement-label">Waist</div>' : '<span class="empty-cell"></span>'}</td>
            <td>${m.pantHip ? '<div class="measurement-value">' + m.pantHip + '</div><div class="measurement-label">Hip</div>' : '<span class="empty-cell"></span>'}</td>
            <td>${m.pantThigh ? '<div class="measurement-value">' + m.pantThigh + '</div><div class="measurement-label">Thigh</div>' : '<span class="empty-cell"></span>'}</td>
            <td>${m.pantMiddle1 ? '<div class="measurement-value">' + m.pantMiddle1 + '</div><div class="measurement-label">Middle 1</div>' : '<span class="empty-cell"></span>'}</td>
            <td>${m.pantMiddle2 ? '<div class="measurement-value">' + m.pantMiddle2 + '</div><div class="measurement-label">Middle 2</div>' : '<span class="empty-cell"></span>'}</td>
          </tr>
          <tr>
            <td>${m.pantQuarter ? '<div class="measurement-value">' + m.pantQuarter + '</div><div class="measurement-label">Quarter</div>' : '<span class="empty-cell"></span>'}</td>
            <td>${m.pantBottom ? '<div class="measurement-value">' + m.pantBottom + '</div><div class="measurement-label">Bottom</div>' : '<span class="empty-cell"></span>'}</td>
            <td>${m.pantHigh ? '<div class="measurement-value">' + m.pantHigh + '</div><div class="measurement-label">High</div>' : '<span class="empty-cell"></span>'}</td>
            <td>${m.pantFront ? '<div class="measurement-value">' + m.pantFront + '</div><div class="measurement-label">Front</div>' : '<span class="empty-cell"></span>'}</td>
            <td>${m.pantBack ? '<div class="measurement-value">' + m.pantBack + '</div><div class="measurement-label">Back</div>' : '<span class="empty-cell"></span>'}</td>
            <td></td>
          </tr>
        </table>
        ` : ''}
        
        ${!hasUpperBodyMeasurements(m) && !hasPantsMeasurements(m) ? '<p>No measurements recorded</p>' : ''}
        
        <div class="no-print">
          <button onclick="window.print()" style="background: #4f46e5; color: white; border: none; padding: 10px 20px; border-radius: 5px; cursor: pointer; font-size: 14px;">Print</button>
          <button onclick="window.close()" style="background: #666; color: white; border: none; padding: 10px 20px; border-radius: 5px; cursor: pointer; font-size: 14px; margin-left: 10px;">Close</button>
        </div>
      </body>
      </html>
    `;
    
    printWindow.document.write(printContent);
    printWindow.document.close();
  };

  return (
    <div className="p-4 md:p-8">
      {/* Header */}
      <div className="flex items-center justify-between mb-8">
        <div>
          <h1 className="text-2xl font-bold text-white">Customers</h1>
          <p className="text-zinc-400 text-sm mt-1">
            Manage your customer profiles and measurements
          </p>
        </div>
        {isAdmin && (
          <button
            onClick={() => setShowAddModal(true)}
            className="flex items-center gap-2 bg-primary hover:bg-primary-hover text-white px-4 py-2 rounded-lg text-sm font-medium transition-all duration-300 glow-button"
          >
            <Plus className="w-4 h-4" />
            New Customer
          </button>
        )}
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
        <div className="bg-zinc-900 border border-zinc-800 rounded-xl p-4 stat-highlight">
          <p className="text-zinc-400 text-xs">Total Customers</p>
          <p className="text-2xl font-bold text-white mt-1">{customers.length}</p>
        </div>
        <div className="bg-zinc-900 border border-zinc-800 rounded-xl p-4">
          <p className="text-zinc-400 text-xs">Total Orders</p>
          <p className="text-2xl font-bold text-white mt-1">{orders.length}</p>
        </div>
        <div className="bg-zinc-900 border border-zinc-800 rounded-xl p-4">
          <p className="text-zinc-400 text-xs">This Month</p>
          <p className="text-2xl font-bold text-white mt-1">{orders.filter(o => {
            const created = new Date(o.createdAt);
            const now = new Date();
            return created.getMonth() === now.getMonth() && created.getFullYear() === now.getFullYear();
          }).length}</p>
        </div>
        <div className="bg-zinc-900 border border-zinc-800 rounded-xl p-4">
          <p className="text-zinc-400 text-xs">Pending</p>
          <p className="text-2xl font-bold text-white mt-1">{orders.filter(o => o.status === "Pending").length}</p>
        </div>
      </div>

      {/* Search */}
      <div className="relative mb-6">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-zinc-500" />
        <input
          type="text"
          placeholder="Search customers..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          className="w-full bg-zinc-900 border border-zinc-800 rounded-lg pl-10 pr-4 py-2.5 text-sm text-white placeholder-zinc-500 focus:outline-none focus:border-primary transition-colors"
        />
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-4 gap-6">
        {/* Customer List */}
        <div className="xl:col-span-1 space-y-3 max-h-[calc(100vh-300px)] overflow-y-auto pr-2">
          {filtered.length === 0 ? (
            <div className="bg-zinc-900 border border-zinc-800 rounded-xl p-8 text-center text-zinc-500 text-sm">
              No customers found
            </div>
          ) : (
            filtered.map((customer) => {
              const customerOrders = getCustomerOrders(customer.id);
              const isSelected = selected?.id === customer.id;
              return (
                <div
                  key={customer.id}
                  onClick={() => setSelected(customer)}
                  className={`bg-zinc-900 border rounded-xl p-4 cursor-pointer transition-all customer-card ${
                    isSelected
                      ? "border-primary"
                      : "border-zinc-800 hover:border-zinc-700"
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <div className="w-12 h-12 avatar-gradient rounded-full flex items-center justify-center flex-shrink-0">
                      <span className="text-sm font-bold text-white">
                        {customer.name
                          .split(" ")
                          .map((n) => n[0])
                          .join("") || "?"}
                      </span>
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-semibold text-white truncate">
                        {customer.name}
                      </p>
                      <p className="text-xs text-zinc-500 truncate">
                        {customer.email}
                      </p>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="text-xs text-zinc-500">
                        {customerOrders.length} orders
                      </span>
                      <ChevronRight className="w-4 h-4 text-zinc-600" />
                    </div>
                  </div>
                </div>
              );
            })
          )}
        </div>

        {/* Customer Detail */}
        <div className="xl:col-span-3">
          {!selected ? (
            <div className="bg-zinc-900 border border-zinc-800 rounded-xl p-12 text-center">
              <div className="w-12 h-12 bg-zinc-800 rounded-full flex items-center justify-center mx-auto mb-3">
                <Search className="w-6 h-6 text-zinc-600" />
              </div>
              <p className="text-zinc-400 text-sm">
                Select a customer to view details
              </p>
            </div>
          ) : (
            <div className="space-y-4">
              {/* Profile Card */}
              <div className="bg-zinc-900 border border-zinc-800 rounded-xl p-5">
                <div className="flex items-start justify-between mb-4">
                  <div className="flex items-center gap-4">
                    <div className="w-14 h-14 bg-primary/20 border border-primary/30 rounded-full flex items-center justify-center">
                      <span className="text-lg font-bold text-primary-light">
                        {selected.name
                          .split(" ")
                          .map((n) => n[0])
                          .join("")}
                      </span>
                    </div>
                    <div>
                      <h2 className="text-lg font-bold text-white">
                        {selected.name}
                      </h2>
                      <p className="text-sm text-zinc-400">{selected.email}</p>
                      <p className="text-sm text-zinc-400">{selected.phone}</p>
                    </div>
                  </div>
                  <div className="flex gap-2">
                      <button
                        onClick={() => openEdit(selected)}
                        className="bg-zinc-800 hover:bg-zinc-700 text-zinc-300 px-3 py-1.5 rounded-lg text-xs font-medium transition-colors"
                      >
                        Edit Customer
                      </button>
                      <button
                        onClick={() => {
                          deleteCustomer(selected.id);
                          setSelected(null);
                        }}
                        className="bg-red-500/10 hover:bg-red-500/20 text-red-400 px-3 py-1.5 rounded-lg text-xs font-medium transition-colors"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                </div>
                <div className="grid grid-cols-2 gap-4 text-sm">
                  <div>
                    <p className="text-zinc-500 text-xs mb-1">Address</p>
                    <p className="text-zinc-300">{selected.address || "—"}</p>
                  </div>
                  <div>
                    <p className="text-zinc-500 text-xs mb-1">Last Visit</p>
                    <p className="text-zinc-300">{selected.lastVisit || "—"}</p>
                  </div>
                  {selected.notes && (
                    <div className="col-span-2">
                      <p className="text-zinc-500 text-xs mb-1">Notes</p>
                      <p className="text-zinc-300">{selected.notes}</p>
                    </div>
                  )}
                </div>
              </div>

              {/* Measurements */}
              <div className="bg-zinc-900 border border-zinc-800 rounded-xl p-5">
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center gap-2">
                    <Ruler className="w-4 h-4 text-primary-light" />
                    <h3 className="font-semibold text-white">Measurements</h3>
                  </div>
                  <button
                    onClick={() => router.push(`/orders?customer=${selected.id}`)}
                    className="bg-zinc-800 hover:bg-zinc-700 text-zinc-300 px-3 py-1.5 rounded-lg text-xs font-medium transition-colors"
                  >
                    New Measurement
                  </button>
                </div>
                <div className="grid grid-cols-5 gap-3">
                  {Object.entries(selected.measurements).map(([key, val]) => (
                    <div
                      key={key}
                      className="bg-zinc-800 rounded-lg p-3 text-center"
                    >
                      <p className="text-lg font-bold text-white">
                        {val || "—"}
                      </p>
                      <p className="text-xs text-zinc-500 capitalize mt-0.5">
                        {key}
                      </p>
                      {val && (
                        <p className="text-xs text-zinc-600">in</p>
                      )}
                    </div>
                  ))}
                </div>
              </div>

              {/* Orders */}
              <div className="bg-zinc-900 border border-zinc-800 rounded-xl p-5">
                <h3 className="font-semibold text-white mb-4">Order History</h3>
                {getCustomerOrders(selected.id).length === 0 ? (
                  <p className="text-zinc-500 text-sm">No orders yet</p>
                ) : (
                  <div className="space-y-2">
                    {getCustomerOrders(selected.id).map((order) => (
                      <div
                        key={order.id}
                        onClick={() => setSelectedOrder(order)}
                        className="flex items-center justify-between py-3 px-3 border border-zinc-800 rounded-lg cursor-pointer hover:border-primary hover:bg-zinc-800/50 transition-all"
                      >
                        <div>
                          <p className="text-sm font-medium text-white">
                            {order.service}
                          </p>
                          <p className="text-xs text-zinc-500">
                            {order.orderNo || order.id} · {order.createdAt}
                          </p>
                        </div>
                        <div className="flex items-center gap-3">
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              handlePrint(order);
                            }}
                            className="p-2 text-zinc-400 hover:text-white hover:bg-zinc-700 rounded-lg transition-colors"
                            title="Print"
                          >
                            <Printer className="w-4 h-4" />
                          </button>
                          <span className="text-sm font-semibold text-white">
                            ${order.price}
                          </span>
                          <span
                            className={`text-xs px-2 py-0.5 rounded-full ${
                              order.status === "Completed"
                                ? "bg-green-500/10 text-green-400"
                                : order.status === "In Progress"
                                ? "bg-blue-500/10 text-blue-400"
                                : "bg-yellow-500/10 text-yellow-400"
                            }`}
                          >
                            {order.status}
                          </span>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Add Customer Modal */}
      {showAddModal && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-50 p-4">
          <div className="bg-zinc-900 border border-zinc-800 rounded-xl w-full max-w-md max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between p-5 border-b border-zinc-800 sticky top-0 bg-zinc-900">
              <h2 className="font-semibold text-white">Create New Customer</h2>
              <button
                onClick={() => setShowAddModal(false)}
                className="text-zinc-500 hover:text-white transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            <form onSubmit={handleAddSubmit} className="p-5 space-y-4">
              <div>
                <label className="block text-xs font-medium text-zinc-400 mb-1.5">
                  Full Name *
                </label>
                <input
                  type="text"
                  placeholder="John Doe"
                  value={form.name}
                  onChange={(e) => setForm({ ...form, name: e.target.value })}
                  required
                  className="w-full bg-zinc-800 border border-zinc-700 text-white text-sm rounded-lg px-3 py-2.5 focus:outline-none focus:border-primary placeholder-zinc-600"
                />
              </div>
              <div>
                <label className="block text-xs font-medium text-zinc-400 mb-1.5">
                  Email
                </label>
                <input
                  type="email"
                  placeholder="john@example.com"
                  value={form.email}
                  onChange={(e) => setForm({ ...form, email: e.target.value })}
                  className="w-full bg-zinc-800 border border-zinc-700 text-white text-sm rounded-lg px-3 py-2.5 focus:outline-none focus:border-primary placeholder-zinc-600"
                />
              </div>
              <div>
                <label className="block text-xs font-medium text-zinc-400 mb-1.5">
                  Phone
                </label>
                <input
                  type="tel"
                  placeholder="+1 555-0000"
                  value={form.phone}
                  onChange={(e) => setForm({ ...form, phone: e.target.value })}
                  className="w-full bg-zinc-800 border border-zinc-700 text-white text-sm rounded-lg px-3 py-2.5 focus:outline-none focus:border-primary placeholder-zinc-600"
                />
              </div>
              <div>
                <label className="block text-xs font-medium text-zinc-400 mb-1.5">
                  Address
                </label>
                <input
                  type="text"
                  placeholder="123 Main St, City"
                  value={form.address}
                  onChange={(e) =>
                    setForm({ ...form, address: e.target.value })
                  }
                  className="w-full bg-zinc-800 border border-zinc-700 text-white text-sm rounded-lg px-3 py-2.5 focus:outline-none focus:border-primary placeholder-zinc-600"
                />
              </div>
              <div>
                <label className="block text-xs font-medium text-zinc-400 mb-1.5">
                  Notes
                </label>
                <textarea
                  placeholder="Any special notes..."
                  value={form.notes}
                  onChange={(e) => setForm({ ...form, notes: e.target.value })}
                  rows={3}
                  className="w-full bg-zinc-800 border border-zinc-700 text-white text-sm rounded-lg px-3 py-2.5 focus:outline-none focus:border-primary placeholder-zinc-600 resize-none"
                />
              </div>
              <div className="flex gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="flex-1 bg-zinc-800 hover:bg-zinc-700 text-zinc-300 px-4 py-2.5 rounded-lg text-sm font-medium transition-colors"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 bg-primary hover:bg-primary text-white px-4 py-2.5 rounded-lg text-sm font-medium transition-colors"
                >
                  Save Customer
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Edit Customer Modal */}
      {showEditModal && selected && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-50 p-4">
          <div className="bg-zinc-900 border border-zinc-800 rounded-xl w-full max-w-md max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between p-5 border-b border-zinc-800 sticky top-0 bg-zinc-900">
              <h2 className="font-semibold text-white">Edit Customer</h2>
              <button
                onClick={() => setShowEditModal(false)}
                className="text-zinc-500 hover:text-white transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            <form onSubmit={handleEditSubmit} className="p-5 space-y-4">
              <div>
                <label className="block text-xs font-medium text-zinc-400 mb-1.5">
                  Full Name *
                </label>
                <input
                  type="text"
                  value={form.name}
                  onChange={(e) => setForm({ ...form, name: e.target.value })}
                  required
                  className="w-full bg-zinc-800 border border-zinc-700 text-white text-sm rounded-lg px-3 py-2.5 focus:outline-none focus:border-primary"
                />
              </div>
              <div>
                <label className="block text-xs font-medium text-zinc-400 mb-1.5">
                  Email
                </label>
                <input
                  type="email"
                  value={form.email}
                  onChange={(e) => setForm({ ...form, email: e.target.value })}
                  className="w-full bg-zinc-800 border border-zinc-700 text-white text-sm rounded-lg px-3 py-2.5 focus:outline-none focus:border-primary"
                />
              </div>
              <div>
                <label className="block text-xs font-medium text-zinc-400 mb-1.5">
                  Phone
                </label>
                <input
                  type="tel"
                  value={form.phone}
                  onChange={(e) => setForm({ ...form, phone: e.target.value })}
                  className="w-full bg-zinc-800 border border-zinc-700 text-white text-sm rounded-lg px-3 py-2.5 focus:outline-none focus:border-primary"
                />
              </div>
              <div>
                <label className="block text-xs font-medium text-zinc-400 mb-1.5">
                  Address
                </label>
                <input
                  type="text"
                  value={form.address}
                  onChange={(e) =>
                    setForm({ ...form, address: e.target.value })
                  }
                  className="w-full bg-zinc-800 border border-zinc-700 text-white text-sm rounded-lg px-3 py-2.5 focus:outline-none focus:border-primary"
                />
              </div>
              <div>
                <label className="block text-xs font-medium text-zinc-400 mb-1.5">
                  Notes
                </label>
                <textarea
                  value={form.notes}
                  onChange={(e) => setForm({ ...form, notes: e.target.value })}
                  rows={3}
                  className="w-full bg-zinc-800 border border-zinc-700 text-white text-sm rounded-lg px-3 py-2.5 focus:outline-none focus:border-primary resize-none"
                />
              </div>
              <div className="flex gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => setShowEditModal(false)}
                  className="flex-1 bg-zinc-800 hover:bg-zinc-700 text-zinc-300 px-4 py-2.5 rounded-lg text-sm font-medium transition-colors"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 bg-primary hover:bg-primary text-white px-4 py-2.5 rounded-lg text-sm font-medium transition-colors"
                >
                  Update Customer
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Measurements Modal */}
      {showMeasurementsModal && selected && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-50 p-4">
          <div className="bg-zinc-900 border border-zinc-800 rounded-xl w-full max-w-md">
            <div className="flex items-center justify-between p-5 border-b border-zinc-800">
              <h2 className="font-semibold text-white">
                New Measurement — {selected.name}
              </h2>
              <button
                onClick={() => setShowMeasurementsModal(false)}
                className="text-zinc-500 hover:text-white transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            <form onSubmit={handleSaveMeasurements} className="p-5 space-y-4">
              {(
                [
                  "chest",
                  "waist",
                  "sleeve",
                  "shoulder",
                  "inseam",
                ] as const
              ).map((field) => (
                <div key={field}>
                  <label className="block text-xs font-medium text-zinc-400 mb-1.5 capitalize">
                    {field} (inches)
                  </label>
                  <input
                    type="number"
                    step="0.5"
                    placeholder="0"
                    value={measurements[field]}
                    onChange={(e) =>
                      setMeasurements({
                        ...measurements,
                        [field]: e.target.value,
                      })
                    }
                    className="w-full bg-zinc-800 border border-zinc-700 text-white text-sm rounded-lg px-3 py-2.5 focus:outline-none focus:border-primary placeholder-zinc-600"
                  />
                </div>
              ))}
              <div className="flex gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => setShowMeasurementsModal(false)}
                  className="flex-1 bg-zinc-800 hover:bg-zinc-700 text-zinc-300 px-4 py-2.5 rounded-lg text-sm font-medium transition-colors"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 bg-primary hover:bg-primary text-white px-4 py-2.5 rounded-lg text-sm font-medium transition-colors"
                >
                  Save Measurements
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Order Details Modal */}
      {selectedOrder && selected && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-50 p-4">
          <div className="bg-zinc-900 border border-zinc-800 rounded-xl w-full max-w-2xl max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between p-5 border-b border-zinc-800 sticky top-0 bg-zinc-900">
              <div>
                <h2 className="font-semibold text-white">Order Details</h2>
                <p className="text-xs text-zinc-500">{selectedOrder.id}</p>
              </div>
              <div className="flex items-center gap-2">
                {isAdmin && (
                  <button
                    onClick={() => openEditOrderMeasurements(selectedOrder)}
                    className="flex items-center gap-2 bg-zinc-700 hover:bg-zinc-600 text-white px-3 py-1.5 rounded-lg text-xs font-medium transition-colors"
                  >
                    <Pencil className="w-3.5 h-3.5" />
                    Edit
                  </button>
                )}
                <button
                  onClick={() => handlePrint(selectedOrder)}
                  className="flex items-center gap-2 bg-primary hover:bg-primary-hover text-white px-3 py-1.5 rounded-lg text-xs font-medium transition-colors"
                >
                  <Printer className="w-3.5 h-3.5" />
                  Print
                </button>
                <button
                  onClick={() => setSelectedOrder(null)}
                  className="text-zinc-500 hover:text-white transition-colors"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>
            <div className="p-5 space-y-5">
              {/* Customer Info */}
              <div className="bg-zinc-800/50 rounded-lg p-4">
                <h3 className="text-sm font-semibold text-white mb-3">Customer Information</h3>
                <div className="grid grid-cols-2 gap-3 text-sm">
                  <div>
                    <p className="text-zinc-500 text-xs">Name</p>
                    <p className="text-white">{selected.name}</p>
                  </div>
                  <div>
                    <p className="text-zinc-500 text-xs">Phone</p>
                    <p className="text-white">{selected.phone || '—'}</p>
                  </div>
                  <div className="col-span-2">
                    <p className="text-zinc-500 text-xs">Address</p>
                    <p className="text-white">{selected.address || '—'}</p>
                  </div>
                </div>
              </div>

              {/* Order Info */}
              <div className="bg-zinc-800/50 rounded-lg p-4">
                <h3 className="text-sm font-semibold text-white mb-3">Order Information</h3>
                <div className="grid grid-cols-2 gap-3 text-sm">
                  <div>
                    <p className="text-zinc-500 text-xs">Service</p>
                    <p className="text-white font-medium">{selectedOrder.service}</p>
                  </div>
                  <div>
                    <p className="text-zinc-500 text-xs">Price</p>
                    <p className="text-white font-medium">${selectedOrder.price}</p>
                  </div>
                  <div>
                    <p className="text-zinc-500 text-xs">Quantity</p>
                    <p className="text-white">{selectedOrder.quantity || '1'}</p>
                  </div>
                  <div>
                    <p className="text-zinc-500 text-xs">Status</p>
                    <span className={`text-xs px-2 py-0.5 rounded-full inline-block ${
                      selectedOrder.status === "Completed" ? "bg-green-500/20 text-green-400" : 
                      selectedOrder.status === "In Progress" ? "bg-blue-500/20 text-blue-400" : 
                      "bg-yellow-500/20 text-yellow-400"
                    }`}>
                      {selectedOrder.status}
                    </span>
                  </div>
                  <div>
                    <p className="text-zinc-500 text-xs">Order Date</p>
                    <p className="text-white">{selectedOrder.createdAt}</p>
                  </div>
                  <div>
                    <p className="text-zinc-500 text-xs">Delivery Date</p>
                    <p className="text-white">{selectedOrder.deliveryDate || '—'}</p>
                  </div>
                  <div>
                    <p className="text-zinc-500 text-xs">Trial Date</p>
                    <p className="text-white">{selectedOrder.trialDate || '—'}</p>
                  </div>
                  {selectedOrder.note && (
                    <div className="col-span-2">
                      <p className="text-zinc-500 text-xs">Note</p>
                      <p className="text-white">{selectedOrder.note}</p>
                    </div>
                  )}
                </div>
              </div>

              {/* Measurements */}
              {(() => {
                const m = getOrderMeasurements(selectedOrder);
                return (
                  <>
                    {hasUpperBodyMeasurements(m) && (
                      <div className="bg-zinc-800/50 rounded-lg p-4">
                        <h3 className="text-sm font-semibold text-white mb-3">Measurements</h3>
                        <div className="grid grid-cols-7 gap-2 text-center">
                          {/* Column 1: Length */}
                          <div className="flex flex-col gap-1">
                            <div className={m.length ? "bg-zinc-800 rounded-lg p-2 h-16 flex flex-col justify-center" : "bg-transparent h-16"}>
                              {m.length && <><p className="text-lg font-bold text-primary-light">{m.length}</p><p className="text-xs text-zinc-500">Length</p></>}
                            </div>
                            {/* Row 2 spacer */}
                            <div className="h-16 bg-transparent"></div>
                            {/* Row 3 spacer */}
                            <div className="h-16 bg-transparent"></div>
                            {/* Row 4: Biceps (M) */}
                            <div className={m.biceps ? "bg-zinc-800 rounded-lg p-2 h-16 flex flex-col justify-center" : "bg-transparent h-16"}>
                              {m.biceps && <><p className="text-lg font-bold text-primary-light">{m.biceps}</p><p className="text-xs text-zinc-500">Biceps (M)</p></>}
                            </div>
                            {/* Row 5: Radius (M) */}
                            <div className={m.radius ? "bg-zinc-800 rounded-lg p-2 h-16 flex flex-col justify-center" : "bg-transparent h-16"}>
                              {m.radius && <><p className="text-lg font-bold text-primary-light">{m.radius}</p><p className="text-xs text-zinc-500">Radius (M)</p></>}
                            </div>
                          </div>
                          
                          {/* Column 2: Chest, Waist, Bottom */}
                          <div className="flex flex-col gap-1">
                            <div className={m.chest ? "bg-zinc-800 rounded-lg p-2 h-16 flex flex-col justify-center" : "bg-transparent h-16"}>
                              {m.chest && <><p className="text-lg font-bold text-primary-light">{m.chest}</p><p className="text-xs text-zinc-500">Chest</p></>}
                            </div>
                            <div className={m.waist ? "bg-zinc-800 rounded-lg p-2 h-16 flex flex-col justify-center" : "bg-transparent h-16"}>
                              {m.waist && <><p className="text-lg font-bold text-primary-light">{m.waist}</p><p className="text-xs text-zinc-500">Waist</p></>}
                            </div>
                            <div className={m.bottom ? "bg-zinc-800 rounded-lg p-2 h-16 flex flex-col justify-center" : "bg-transparent h-16"}>
                              {m.bottom && <><p className="text-lg font-bold text-primary-light">{m.bottom}</p><p className="text-xs text-zinc-500">Bottom</p></>}
                            </div>
                            {/* Spacer for rows 4-5 */}
                            <div className="h-32 bg-transparent"></div>
                          </div>
                          
                          {/* Column 3: Shoulder */}
                          <div className="flex flex-col gap-1">
                            <div className={m.shoulder ? "bg-zinc-800 rounded-lg p-2 h-16 flex flex-col justify-center" : "bg-transparent h-16"}>
                              {m.shoulder && <><p className="text-lg font-bold text-primary-light">{m.shoulder}</p><p className="text-xs text-zinc-500">Shoulder</p></>}
                            </div>
                            {/* Spacer for rows 2-5 */}
                            <div className="h-64 bg-transparent"></div>
                          </div>
                          
                          {/* Column 4: Sleeves, Cuff */}
                          <div className="flex flex-col gap-1">
                            <div className={m.sleeves ? "bg-zinc-800 rounded-lg p-2 h-16 flex flex-col justify-center" : "bg-transparent h-16"}>
                              {m.sleeves && <><p className="text-lg font-bold text-primary-light">{m.sleeves}</p><p className="text-xs text-zinc-500">Sleeves</p></>}
                            </div>
                            <div className={m.cuff ? "bg-zinc-800 rounded-lg p-2 h-16 flex flex-col justify-center" : "bg-transparent h-16"}>
                              {m.cuff && <><p className="text-lg font-bold text-primary-light">{m.cuff}</p><p className="text-xs text-zinc-500">Cuff</p></>}
                            </div>
                            {/* Spacer for rows 3-5 */}
                            <div className="h-48 bg-transparent"></div>
                          </div>
                          
                          {/* Column 5: Collar */}
                          <div className="flex flex-col gap-1">
                            <div className={m.collar ? "bg-zinc-800 rounded-lg p-2 h-16 flex flex-col justify-center" : "bg-transparent h-16"}>
                              {m.collar && <><p className="text-lg font-bold text-primary-light">{m.collar}</p><p className="text-xs text-zinc-500">Collar</p></>}
                            </div>
                            {/* Spacer for rows 2-5 */}
                            <div className="h-64 bg-transparent"></div>
                          </div>
                          
                          {/* Column 6: Front & Back */}
                          <div className="flex flex-col gap-1">
                            {/* Row 1: Front 1 + Back 1 */}
                            <div className="flex gap-1">
                              <div className={m.front1 ? "bg-zinc-800 rounded-lg p-2 h-16 flex-1 flex flex-col justify-center" : "bg-transparent h-16 flex-1"}>
                                {m.front1 && <><p className="text-lg font-bold text-primary-light">{m.front1}</p><p className="text-xs text-zinc-500">Front (1)</p></>}
                              </div>
                              <div className={m.back1 ? "bg-zinc-800 rounded-lg p-2 h-16 flex-1 flex flex-col justify-center" : "bg-transparent h-16 flex-1"}>
                                {m.back1 && <><p className="text-lg font-bold text-primary-light">{m.back1}</p><p className="text-xs text-zinc-500">Back (1)</p></>}
                              </div>
                            </div>
                            {/* Row 2: Front 2 + Back 2 */}
                            <div className="flex gap-1">
                              <div className={m.front2 ? "bg-zinc-800 rounded-lg p-2 h-16 flex-1 flex flex-col justify-center" : "bg-transparent h-16 flex-1"}>
                                {m.front2 && <><p className="text-lg font-bold text-primary-light">{m.front2}</p><p className="text-xs text-zinc-500">Front (2)</p></>}
                              </div>
                              <div className={m.back2 ? "bg-zinc-800 rounded-lg p-2 h-16 flex-1 flex flex-col justify-center" : "bg-transparent h-16 flex-1"}>
                                {m.back2 && <><p className="text-lg font-bold text-primary-light">{m.back2}</p><p className="text-xs text-zinc-500">Back (2)</p></>}
                              </div>
                            </div>
                            {/* Row 3: Front 3 + Back 3 */}
                            <div className="flex gap-1">
                              <div className={m.front3 ? "bg-zinc-800 rounded-lg p-2 h-16 flex-1 flex flex-col justify-center" : "bg-transparent h-16 flex-1"}>
                                {m.front3 && <><p className="text-lg font-bold text-primary-light">{m.front3}</p><p className="text-xs text-zinc-500">Front (3)</p></>}
                              </div>
                              <div className={m.back3 ? "bg-zinc-800 rounded-lg p-2 h-16 flex-1 flex flex-col justify-center" : "bg-transparent h-16 flex-1"}>
                                {m.back3 && <><p className="text-lg font-bold text-primary-light">{m.back3}</p><p className="text-xs text-zinc-500">Back (3)</p></>}
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    )}
                    
                    {hasPantsMeasurements(m) && (
                      <div className="bg-zinc-800/50 rounded-lg p-4">
                        <h3 className="text-sm font-semibold text-white mb-3">Pants Measurements</h3>
                        <div className="grid grid-cols-3 sm:grid-cols-4 gap-3">
                          {m.pantLength && <div className="bg-zinc-800 rounded-lg p-3 text-center"><p className="text-lg font-bold text-primary-light">{m.pantLength}</p><p className="text-xs text-zinc-500">Length</p></div>}
                          {m.pantWaist && <div className="bg-zinc-800 rounded-lg p-3 text-center"><p className="text-lg font-bold text-primary-light">{m.pantWaist}</p><p className="text-xs text-zinc-500">Waist</p></div>}
                          {m.pantHip && <div className="bg-zinc-800 rounded-lg p-3 text-center"><p className="text-lg font-bold text-primary-light">{m.pantHip}</p><p className="text-xs text-zinc-500">Hip</p></div>}
                          {m.pantThigh && <div className="bg-zinc-800 rounded-lg p-3 text-center"><p className="text-lg font-bold text-primary-light">{m.pantThigh}</p><p className="text-xs text-zinc-500">Thigh</p></div>}
                          {m.pantMiddle1 && <div className="bg-zinc-800 rounded-lg p-3 text-center"><p className="text-lg font-bold text-primary-light">{m.pantMiddle1}</p><p className="text-xs text-zinc-500">Middle 1</p></div>}
                          {m.pantMiddle2 && <div className="bg-zinc-800 rounded-lg p-3 text-center"><p className="text-lg font-bold text-primary-light">{m.pantMiddle2}</p><p className="text-xs text-zinc-500">Middle 2</p></div>}
                          {m.pantQuarter && <div className="bg-zinc-800 rounded-lg p-3 text-center"><p className="text-lg font-bold text-primary-light">{m.pantQuarter}</p><p className="text-xs text-zinc-500">Quarter</p></div>}
                          {m.pantBottom && <div className="bg-zinc-800 rounded-lg p-3 text-center"><p className="text-lg font-bold text-primary-light">{m.pantBottom}</p><p className="text-xs text-zinc-500">Bottom</p></div>}
                          {m.pantHigh && <div className="bg-zinc-800 rounded-lg p-3 text-center"><p className="text-lg font-bold text-primary-light">{m.pantHigh}</p><p className="text-xs text-zinc-500">High</p></div>}
                          {m.pantFront && <div className="bg-zinc-800 rounded-lg p-3 text-center"><p className="text-lg font-bold text-primary-light">{m.pantFront}</p><p className="text-xs text-zinc-500">Front</p></div>}
                          {m.pantBack && <div className="bg-zinc-800 rounded-lg p-3 text-center"><p className="text-lg font-bold text-primary-light">{m.pantBack}</p><p className="text-xs text-zinc-500">Back</p></div>}
                        </div>
                      </div>
                    )}
                  </>
                );
              })()}
            </div>
          </div>
        </div>
      )}

      {/* Edit Order Measurements Modal */}
      {showEditMeasurementsModal && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-50 p-4">
          <div className="bg-zinc-900 border border-zinc-800 rounded-xl w-full max-w-2xl max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between p-5 border-b border-zinc-800 sticky top-0 bg-zinc-900">
              <h2 className="font-semibold text-white">Edit Measurements</h2>
              <button
                onClick={() => setShowEditMeasurementsModal(false)}
                className="text-zinc-500 hover:text-white transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            <div className="p-5 space-y-4">
              <div>
                <h3 className="text-sm font-semibold text-white mb-3">Upper Body Measurements</h3>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                  {[
                    { key: 'measurementLength', label: 'Length' },
                    { key: 'measurementBody1', label: 'Chest' },
                    { key: 'measurementBody2', label: 'Waist' },
                    { key: 'measurementBody3', label: 'Bottom' },
                    { key: 'measurementShoulder', label: 'Shoulder' },
                    { key: 'measurementSleeves', label: 'Sleeves' },
                    { key: 'measurementCuff', label: 'Cuff' },
                    { key: 'measurementCollar', label: 'Collar' },
                    { key: 'measurementFront1', label: 'Front 1' },
                    { key: 'measurementFront2', label: 'Front 2' },
                    { key: 'measurementFront3', label: 'Front 3' },
                    { key: 'measurementBack1', label: 'Back 1' },
                    { key: 'measurementBack2', label: 'Back 2' },
                    { key: 'measurementBack3', label: 'Back 3' },
                    { key: 'measurementBiceps', label: 'Biceps (M)' },
                    { key: 'measurementRadius', label: 'Radius (M)' },
                  ].map(({ key, label }) => (
                    <div key={key}>
                      <label className="block text-xs text-zinc-400 mb-1">{label}</label>
                      <input
                        type="text"
                        value={editOrderMeasurements[key] || ''}
                        onChange={(e) => setEditOrderMeasurements({ ...editOrderMeasurements, [key]: e.target.value })}
                        className="w-full bg-zinc-800 border border-zinc-700 text-white text-sm rounded px-2 py-1.5 focus:outline-none focus:border-primary"
                      />
                    </div>
                  ))}
                </div>
              </div>
              <div>
                <h3 className="text-sm font-semibold text-white mb-3">Pants Measurements</h3>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                  {[
                    { key: 'pantLength', label: 'Length' },
                    { key: 'pantWaist', label: 'Waist' },
                    { key: 'pantHip', label: 'Hip' },
                    { key: 'pantThigh', label: 'Thigh' },
                    { key: 'pantMiddle1', label: 'Middle 1' },
                    { key: 'pantMiddle2', label: 'Middle 2' },
                    { key: 'pantQuarter', label: 'Quarter' },
                    { key: 'pantBottom', label: 'Bottom' },
                    { key: 'pantHigh', label: 'High' },
                    { key: 'pantFront', label: 'Front' },
                    { key: 'pantBack', label: 'Back' },
                  ].map(({ key, label }) => (
                    <div key={key}>
                      <label className="block text-xs text-zinc-400 mb-1">{label}</label>
                      <input
                        type="text"
                        value={editOrderMeasurements[key] || ''}
                        onChange={(e) => setEditOrderMeasurements({ ...editOrderMeasurements, [key]: e.target.value })}
                        className="w-full bg-zinc-800 border border-zinc-700 text-white text-sm rounded px-2 py-1.5 focus:outline-none focus:border-primary"
                      />
                    </div>
                  ))}
                </div>
              </div>
              <div className="flex justify-end gap-3 pt-3">
                <button
                  onClick={() => setShowEditMeasurementsModal(false)}
                  className="px-4 py-2 bg-zinc-700 hover:bg-zinc-600 text-white rounded-lg text-sm font-medium transition-colors"
                >
                  Cancel
                </button>
                <button
                  onClick={handleSaveOrderMeasurements}
                  className="flex items-center gap-2 px-4 py-2 bg-primary hover:bg-primary-hover text-white rounded-lg text-sm font-medium transition-colors"
                >
                  <Save className="w-4 h-4" />
                  Save Measurements
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export default function CustomersPage() {
  return (
    <Suspense fallback={<div className="p-8 text-white">Loading...</div>}>
      <CustomersContent />
    </Suspense>
  );
}
