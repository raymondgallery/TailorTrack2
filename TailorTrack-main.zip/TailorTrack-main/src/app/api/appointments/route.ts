export const dynamic = "force-dynamic";

import { NextResponse } from "next/server";
import { db } from "@/db";
import { appointments } from "@/db/schema";
import { eq } from "drizzle-orm";

// GET /api/appointments
export async function GET() {
  try {
    const rows = await db.select().from(appointments);
    return NextResponse.json(rows);
  } catch (error) {
    console.error("GET /api/appointments error:", error);
    return NextResponse.json({ error: "Failed to fetch appointments" }, { status: 500 });
  }
}

// POST /api/appointments
export async function POST(request: Request) {
  try {
    const body = await request.json();
    const { time, customer, service, type, date } = body;
    
    if (!time || !customer || !service || !type || !date) {
      return NextResponse.json({ error: "Missing required fields" }, { status: 400 });
    }
    
    const id = `apt_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    
    await db.insert(appointments).values({
      id,
      time,
      customer,
      service,
      type,
      date,
    });
    
    return NextResponse.json({ id, time, customer, service, type, date });
  } catch (error) {
    console.error("POST /api/appointments error:", error);
    return NextResponse.json({ error: "Failed to create appointment" }, { status: 500 });
  }
}

// DELETE /api/appointments?id=xxx
export async function DELETE(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const id = searchParams.get("id");
    
    if (!id) {
      return NextResponse.json({ error: "Missing appointment ID" }, { status: 400 });
    }
    
    await db.delete(appointments).where(eq(appointments.id, id));
    
    return NextResponse.json({ success: true });
  } catch (error) {
    console.error("DELETE /api/appointments error:", error);
    return NextResponse.json({ error: "Failed to delete appointment" }, { status: 500 });
  }
}
