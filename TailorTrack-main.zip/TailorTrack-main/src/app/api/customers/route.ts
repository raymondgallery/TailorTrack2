export const dynamic = "force-dynamic";

import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { customers } from "@/db/schema";
import { eq } from "drizzle-orm";

// GET /api/customers
export async function GET() {
  try {
    const rows = await db.select().from(customers);
    // Map DB rows to Customer shape
    const result = rows.map((r) => ({
      id: r.id,
      name: r.name,
      email: r.email,
      phone: r.phone,
      address: r.address,
      notes: r.notes,
      lastVisit: r.lastVisit,
      measurements: {
        chest: r.measurementChest,
        waist: r.measurementWaist,
        sleeve: r.measurementSleeve,
        shoulder: r.measurementShoulder,
        inseam: r.measurementInseam,
      },
    }));
    return NextResponse.json(result);
  } catch (error) {
    console.error("GET /api/customers error:", error);
    return NextResponse.json({ error: "Failed to fetch customers" }, { status: 500 });
  }
}

// POST /api/customers
export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const id = Date.now().toString();
    await db.insert(customers).values({
      id,
      name: body.name ?? "",
      email: body.email ?? "",
      phone: body.phone ?? "",
      address: body.address ?? "",
      notes: body.notes ?? "",
      lastVisit: body.lastVisit ?? "",
      measurementChest: body.measurements?.chest ?? "",
      measurementWaist: body.measurements?.waist ?? "",
      measurementSleeve: body.measurements?.sleeve ?? "",
      measurementShoulder: body.measurements?.shoulder ?? "",
      measurementInseam: body.measurements?.inseam ?? "",
    });
    return NextResponse.json({ id });
  } catch (error) {
    console.error("POST /api/customers error:", error);
    return NextResponse.json({ error: "Failed to create customer" }, { status: 500 });
  }
}

// PATCH /api/customers?id=...
export async function PATCH(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url);
    const id = searchParams.get("id");
    if (!id) return NextResponse.json({ error: "Missing id" }, { status: 400 });

    const body = await req.json();
    const updateData: Record<string, string> = {};

    if (body.name !== undefined) updateData.name = body.name;
    if (body.email !== undefined) updateData.email = body.email;
    if (body.phone !== undefined) updateData.phone = body.phone;
    if (body.address !== undefined) updateData.address = body.address;
    if (body.notes !== undefined) updateData.notes = body.notes;
    if (body.lastVisit !== undefined) updateData.lastVisit = body.lastVisit;
    if (body.measurements?.chest !== undefined) updateData.measurementChest = body.measurements.chest;
    if (body.measurements?.waist !== undefined) updateData.measurementWaist = body.measurements.waist;
    if (body.measurements?.sleeve !== undefined) updateData.measurementSleeve = body.measurements.sleeve;
    if (body.measurements?.shoulder !== undefined) updateData.measurementShoulder = body.measurements.shoulder;
    if (body.measurements?.inseam !== undefined) updateData.measurementInseam = body.measurements.inseam;

    await db.update(customers).set(updateData).where(eq(customers.id, id));
    return NextResponse.json({ success: true });
  } catch (error) {
    console.error("PATCH /api/customers error:", error);
    return NextResponse.json({ error: "Failed to update customer" }, { status: 500 });
  }
}

// DELETE /api/customers?id=...
export async function DELETE(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url);
    const id = searchParams.get("id");
    if (!id) return NextResponse.json({ error: "Missing id" }, { status: 400 });

    await db.delete(customers).where(eq(customers.id, id));
    return NextResponse.json({ success: true });
  } catch (error) {
    console.error("DELETE /api/customers error:", error);
    return NextResponse.json({ error: "Failed to delete customer" }, { status: 500 });
  }
}
