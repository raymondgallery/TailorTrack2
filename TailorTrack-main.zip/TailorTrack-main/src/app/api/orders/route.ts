export const dynamic = "force-dynamic";

import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { orders } from "@/db/schema";
import { eq } from "drizzle-orm";

// GET /api/orders
export async function GET() {
  try {
    const rows = await db.select().from(orders);
    return NextResponse.json(rows);
  } catch (error) {
    console.error("GET /api/orders error:", error);
    return NextResponse.json({ error: "Failed to fetch orders" }, { status: 500 });
  }
}

// POST /api/orders
export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    // Use provided orderNo as ID, or generate one automatically
    const id = body.orderNo?.trim() || `ORD-${Date.now()}`;
    const createdAt = new Date().toISOString().split("T")[0];
    await db.insert(orders).values({
      id,
      customerId: body.customerId,
      service: body.service,
      quantity: body.quantity ?? "",
      price: body.price,
      status: body.status ?? "Pending",
      createdAt,
      deliveryDate: body.deliveryDate ?? "",
      trialDate: body.trialDate ?? "",
      note: body.note ?? "",
      // Upper body measurement fields
      measurementLength: body.measurementLength ?? "",
      measurementBody1: body.measurementBody1 ?? "",
      measurementBody2: body.measurementBody2 ?? "",
      measurementBody3: body.measurementBody3 ?? "",
      measurementShoulder: body.measurementShoulder ?? "",
      measurementSleeves: body.measurementSleeves ?? "",
      measurementCuff: body.measurementCuff ?? "",
      measurementCollar: body.measurementCollar ?? "",
      measurementFront1: body.measurementFront1 ?? "",
      measurementFront2: body.measurementFront2 ?? "",
      measurementFront3: body.measurementFront3 ?? "",
      measurementBack1: body.measurementBack1 ?? "",
      measurementBack2: body.measurementBack2 ?? "",
      measurementBack3: body.measurementBack3 ?? "",
      measurementBiceps: body.measurementBiceps ?? "",
      measurementRadius: body.measurementRadius ?? "",
      // Pants measurement fields
      pantLength: body.pantLength ?? "",
      pantWaist: body.pantWaist ?? "",
      pantHip: body.pantHip ?? "",
      pantThigh: body.pantThigh ?? "",
      pantMiddle1: body.pantMiddle1 ?? "",
      pantMiddle2: body.pantMiddle2 ?? "",
      pantQuarter: body.pantQuarter ?? "",
      pantBottom: body.pantBottom ?? "",
      pantHigh: body.pantHigh ?? "",
      pantFront: body.pantFront ?? "",
      pantBack: body.pantBack ?? "",
    });
    return NextResponse.json({ id, createdAt });
  } catch (error) {
    console.error("POST /api/orders error:", error);
    return NextResponse.json({ error: "Failed to create order" }, { status: 500 });
  }
}

// PATCH /api/orders?id=...
export async function PATCH(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url);
    const id = searchParams.get("id");
    if (!id) return NextResponse.json({ error: "Missing id" }, { status: 400 });

    const body = await req.json();
    const updateData: Record<string, string> = {};

    if (body.status !== undefined) updateData.status = body.status;
    if (body.service !== undefined) updateData.service = body.service;
    if (body.price !== undefined) updateData.price = body.price;
    if (body.deliveryDate !== undefined) updateData.deliveryDate = body.deliveryDate;

    await db.update(orders).set(updateData).where(eq(orders.id, id));
    return NextResponse.json({ success: true });
  } catch (error) {
    console.error("PATCH /api/orders error:", error);
    return NextResponse.json({ error: "Failed to update order" }, { status: 500 });
  }
}

// DELETE /api/orders?id=...
export async function DELETE(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url);
    const id = searchParams.get("id");
    if (!id) return NextResponse.json({ error: "Missing id" }, { status: 400 });

    await db.delete(orders).where(eq(orders.id, id));
    return NextResponse.json({ success: true });
  } catch (error) {
    console.error("DELETE /api/orders error:", error);
    return NextResponse.json({ error: "Failed to delete order" }, { status: 500 });
  }
}
