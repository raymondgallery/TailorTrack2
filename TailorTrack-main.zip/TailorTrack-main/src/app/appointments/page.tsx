"use client";

import { useApp } from "@/lib/context";
import { Clock, Calendar, User, Tag, Plus, X, ChevronLeft, ChevronRight } from "lucide-react";
import { useState } from "react";

const appointmentTypeColors: Record<string, string> = {
  "Final Fitting": "bg-green-500/10 text-green-400 border border-green-500/20",
  "Pick-up": "bg-blue-500/10 text-blue-400 border border-blue-500/20",
  Consultation: "bg-purple-500/10 text-purple-400 border border-purple-500/20",
  "Initial Measurement": "bg-slate-500/10 text-slate-400 border border-slate-500/20",
};

const APPOINTMENT_TYPES = ["Final Fitting", "Pick-up", "Consultation", "Initial Measurement"];

const TIME_SLOTS = [
  "09:00 AM", "09:30 AM", "10:00 AM", "10:30 AM", "11:00 AM", "11:30 AM",
  "12:00 PM", "12:30 PM", "01:00 PM", "01:30 PM", "02:00 PM", "02:30 PM",
  "03:00 PM", "03:30 PM", "04:00 PM", "04:30 PM", "05:00 PM", "05:30 PM",
  "06:00 PM", "06:30 PM", "07:00 PM", "07:30 PM", "08:00 PM",
];

// Helper to get date string for a given offset (in days)
function getDateString(offset: number): string {
  const date = new Date();
  date.setDate(date.getDate() + offset);
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  date.setHours(0, 0, 0, 0);
  
  const diff = Math.round((date.getTime() - today.getTime()) / (1000 * 60 * 60 * 24));
  
  if (diff === 0) return "Today";
  if (diff === 1) return "Tomorrow";
  return date.toLocaleDateString("en-US", { weekday: "long", month: "short", day: "numeric" });
}

// Helper to parse stored date string to Date object
function parseStoredDate(dateStr: string): Date {
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  
  if (dateStr === "Today") return today;
  if (dateStr === "Tomorrow") {
    const tomorrow = new Date(today);
    tomorrow.setDate(tomorrow.getDate() + 1);
    return tomorrow;
  }
  
  // Try to parse "Weekday, Month Day" format
  const parsed = new Date(dateStr);
  if (!isNaN(parsed.getTime())) return parsed;
  
  return today;
}

export default function AppointmentsPage() {
  const { appointments, isAdmin, addAppointment, deleteAppointment, customers, orders } = useApp();
  const [showModal, setShowModal] = useState(false);
  const [showOrdersPanel, setShowOrdersPanel] = useState(false);
  const [selectedDateOrders, setSelectedDateOrders] = useState<{
    date: string;
    orders: any[];
  } | null>(null);
  const [selectedDate, setSelectedDate] = useState("");
  const [formData, setFormData] = useState({ time: "", customer: "", service: "", type: "", date: "" });
  const [saving, setSaving] = useState(false);
  
  // Calendar state
  const [currentDate, setCurrentDate] = useState(new Date());
  
  const getMonthDays = (date: Date) => {
    const year = date.getFullYear();
    const month = date.getMonth();
    const firstDay = new Date(year, month, 1);
    const lastDay = new Date(year, month + 1, 0);
    const days: (Date | null)[] = [];
    
    // Add empty slots for days before first day of month
    const startPadding = firstDay.getDay();
    for (let i = 0; i < startPadding; i++) {
      days.push(null);
    }
    
    // Add all days of the month
    for (let i = 1; i <= lastDay.getDate(); i++) {
      days.push(new Date(year, month, i));
    }
    
    return days;
  };
  
  const monthNames = ["January", "February", "March", "April", "May", "June", 
                      "July", "August", "September", "October", "November", "December"];
  const dayNames = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
  
  const calendarDays = getMonthDays(currentDate);
  
  const getAppointmentsForDate = (date: Date) => {
    const dateStr = date.toLocaleDateString("en-US", { weekday: "long", month: "short", day: "numeric" });
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    date.setHours(0, 0, 0, 0);
    
    return appointments.filter(apt => {
      if (apt.date === "Today" && date.getTime() === today.getTime()) return true;
      if (apt.date === "Tomorrow") {
        const tomorrow = new Date(today);
        tomorrow.setDate(tomorrow.getDate() + 1);
        return date.getTime() === tomorrow.getTime();
      }
      return apt.date === dateStr;
    });
  };
  
  const prevMonth = () => {
    setCurrentDate(new Date(currentDate.getFullYear(), currentDate.getMonth() - 1, 1));
  };
  
  const nextMonth = () => {
    setCurrentDate(new Date(currentDate.getFullYear(), currentDate.getMonth() + 1, 1));
  };
  
  const goToToday = () => {
    setCurrentDate(new Date());
  };
  
  const handleDayClick = (date: Date) => {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    date.setHours(0, 0, 0, 0);
    
    let dateStr: string;
    const diff = Math.round((date.getTime() - today.getTime()) / (1000 * 60 * 60 * 24));
    
    if (diff === 0) dateStr = "Today";
    else if (diff === 1) dateStr = "Tomorrow";
    else dateStr = date.toLocaleDateString("en-US", { weekday: "long", month: "short", day: "numeric" });
    
    // Get orders for this date (Trial or Delivery)
    const targetDate = new Date(date);
    const dateOrders = orders.filter(order => 
      isDateMatch(order.trialDate, targetDate) || 
      isDateMatch(order.deliveryDate, targetDate)
    );
    
    setSelectedDateOrders({ date: dateStr, orders: dateOrders });
    setShowOrdersPanel(true);
  };
  
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.time || !formData.customer || !formData.service || !formData.type || !formData.date) return;
    setSaving(true);
    try {
      await addAppointment(formData);
      setShowModal(false);
      setFormData({ time: "", customer: "", service: "", type: "", date: "" });
      setSelectedDate("");
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async (id: string) => {
    if (!confirm("Are you sure you want to delete this appointment?")) return;
    await deleteAppointment(id);
  };

  const today = new Date();
  today.setHours(0, 0, 0, 0);

  // Helper to get date strings for upcoming days
  const getDateForDay = (offset: number): Date => {
    const date = new Date();
    date.setDate(date.getDate() + offset);
    date.setHours(0, 0, 0, 0);
    return date;
  };

  const getDateStringForOffset = (offset: number): string => {
    const date = getDateForDay(offset);
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const diff = Math.round((date.getTime() - today.getTime()) / (1000 * 60 * 60 * 24));
    
    if (diff === 0) return "Today";
    if (diff === 1) return "Tomorrow";
    return date.toLocaleDateString("en-US", { weekday: "long", month: "short", day: "numeric" });
  };

  // Helper to compare date strings with a target date
  const isDateMatch = (dateStr: string, targetDate: Date): boolean => {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    
    if (dateStr === "Today") {
      return targetDate.getTime() === today.getTime();
    }
    if (dateStr === "Tomorrow") {
      const tomorrow = new Date(today);
      tomorrow.setDate(tomorrow.getDate() + 1);
      return targetDate.getTime() === tomorrow.getTime();
    }
    
    const parsed = new Date(dateStr);
    if (!isNaN(parsed.getTime())) {
      parsed.setHours(0, 0, 0, 0);
      return parsed.getTime() === targetDate.getTime();
    }
    return false;
  };

  // Helper to parse selected date string to Date object
  const parseSelectedDate = (dateStr: string): Date => {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    
    if (dateStr === "Today") return today;
    if (dateStr === "Tomorrow") {
      const tomorrow = new Date(today);
      tomorrow.setDate(tomorrow.getDate() + 1);
      return tomorrow;
    }
    
    const parsed = new Date(dateStr);
    if (!isNaN(parsed.getTime())) {
      parsed.setHours(0, 0, 0, 0);
      return parsed;
    }
    return today;
  };

  // Get orders for a specific date (by trialDate or deliveryDate)
  const getOrdersForDate = (dateOffset: number) => {
    const targetDate = getDateForDay(dateOffset);
    return orders.filter(order => 
      isDateMatch(order.trialDate, targetDate) || 
      isDateMatch(order.deliveryDate, targetDate)
    );
  };

  // Get customer name by ID
  const getCustomerName = (customerId: string) => {
    const customer = customers.find(c => c.id === customerId);
    return customer?.name || "Unknown";
  };

  return (
    <div className="p-4 md:p-8">
      {/* Header */}
      <div className="flex items-center justify-between mb-6 md:mb-8">
        <div>
          <h1 className="text-xl md:text-2xl font-bold text-white">Appointments</h1>
          <p className="text-zinc-400 text-sm mt-1">
            View and manage your appointments calendar
          </p>
        </div>
      </div>

      {/* Calendar Navigation */}
      <div className="bg-zinc-900 border border-zinc-800 rounded-xl p-4 mb-6">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <button
              onClick={prevMonth}
              className="p-2 hover:bg-zinc-800 rounded-lg transition-colors"
            >
              <ChevronLeft className="w-5 h-5 text-zinc-400" />
            </button>
            <h2 className="text-lg font-semibold text-white min-w-[180px] text-center">
              {monthNames[currentDate.getMonth()]} {currentDate.getFullYear()}
            </h2>
            <button
              onClick={nextMonth}
              className="p-2 hover:bg-zinc-800 rounded-lg transition-colors"
            >
              <ChevronRight className="w-5 h-5 text-zinc-400" />
            </button>
          </div>
          <button
            onClick={goToToday}
            className="px-3 py-1.5 bg-primary hover:bg-primary text-white text-sm rounded-lg transition-colors"
          >
            Today
          </button>
        </div>
        
        {/* Calendar Grid */}
        <div className="grid grid-cols-7 gap-1">
          {dayNames.map((day) => (
            <div key={day} className="text-center text-xs font-medium text-zinc-500 py-2">
              {day}
            </div>
          ))}
          {calendarDays.map((date, idx) => {
            if (!date) {
              return <div key={`empty-${idx}`} className="h-24" />;
            }
            
            const dayAppointments = getAppointmentsForDate(date);
            const isToday = date.getTime() === today.getTime();
            const isPast = date.getTime() < today.getTime();
            
            return (
              <div
                key={date.toISOString()}
                onClick={() => !isPast && handleDayClick(date)}
                className={`h-24 border rounded-lg p-1.5 overflow-hidden cursor-pointer transition-colors ${
                  isToday 
                    ? "border-primary bg-primary/10" 
                    : isPast
                      ? "border-zinc-800 bg-zinc-800/30 opacity-50 cursor-not-allowed"
                      : "border-zinc-800 hover:border-zinc-700 bg-zinc-900"
                }`}
              >
                <div className={`text-xs font-medium mb-1 ${isToday ? "text-primary-light" : "text-zinc-400"}`}>
                  {date.getDate()}
                </div>
                <div className="space-y-1">
                  {dayAppointments.slice(0, 3).map((apt) => (
                    <div
                      key={apt.id}
                      className={`text-[10px] px-1.5 py-0.5 rounded truncate ${
                        appointmentTypeColors[apt.type] || "bg-zinc-700 text-zinc-300"
                      }`}
                      title={`${apt.time} - ${apt.customer}`}
                    >
                      {apt.time} {apt.customer}
                    </div>
                  ))}
                  {dayAppointments.length > 3 && (
                    <div className="text-[10px] text-zinc-500">
                      +{dayAppointments.length - 3} more
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Today's Appointments Summary */}
      <div className="bg-zinc-900 border border-zinc-800 rounded-xl p-5">
        <h3 className="text-lg font-semibold text-white mb-4">Today&apos;s Schedule</h3>
        {appointments.filter(a => a.date === "Today").length === 0 ? (
          <p className="text-zinc-500 text-sm">No appointments for today</p>
        ) : (
          <div className="space-y-3">
            {appointments
              .filter(a => a.date === "Today")
              .map((apt) => (
                <div
                  key={apt.id}
                  className="bg-zinc-800 border border-zinc-700 rounded-lg p-3"
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <Clock className="w-4 h-4 text-primary-light" />
                      <span className="text-sm font-medium text-white">{apt.time}</span>
                      <span className={`text-xs px-2 py-0.5 rounded-full ${
                        appointmentTypeColors[apt.type] || "bg-zinc-700 text-zinc-300"
                      }`}>
                        {apt.type}
                      </span>
                    </div>
                    {isAdmin && (
                      <button
                        onClick={() => handleDelete(apt.id)}
                        className="text-zinc-500 hover:text-red-400 p-1 rounded transition-colors"
                      >
                        <X className="w-4 h-4" />
                      </button>
                    )}
                  </div>
                  <div className="mt-2 flex items-center gap-4 text-xs text-zinc-400">
                    <span className="flex items-center gap-1">
                      <User className="w-3 h-3" />
                      {apt.customer}
                    </span>
                    <span className="flex items-center gap-1">
                      <Tag className="w-3 h-3" />
                      {apt.service}
                    </span>
                  </div>
                </div>
              ))}
          </div>
        )}
      </div>

      {/* Order Tables for Upcoming Dates */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-6">
        {/* Today */}
        <div className="bg-zinc-900 border border-zinc-800 rounded-xl p-4">
          <h3 className="text-lg font-semibold text-white mb-3">Today</h3>
          {getOrdersForDate(0).length === 0 ? (
            <p className="text-zinc-500 text-sm">No orders for today</p>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="text-left text-zinc-500 border-b border-zinc-800">
                    <th className="pb-2 font-medium">Order No</th>
                    <th className="pb-2 font-medium">Customer</th>
                    <th className="pb-2 font-medium">Service</th>
                    <th className="pb-2 font-medium">Type</th>
                  </tr>
                </thead>
                <tbody>
                  {getOrdersForDate(0).map((order) => (
                    <tr key={order.id} className="border-b border-zinc-800/50">
                      <td className="py-2 text-white">{order.orderNo || order.id}</td>
                      <td className="py-2 text-zinc-300">{getCustomerName(order.customerId)}</td>
                      <td className="py-2 text-zinc-300">{order.service}</td>
                      <td className="py-2">
                        {isDateMatch(order.trialDate, getDateForDay(0)) && (
                          <span className="inline-block px-2 py-0.5 bg-slate-500/10 text-slate-400 border border-slate-500/20 rounded text-xs mr-1">
                            Trial
                          </span>
                        )}
                        {isDateMatch(order.deliveryDate, getDateForDay(0)) && (
                          <span className="inline-block px-2 py-0.5 bg-green-500/10 text-green-400 border border-green-500/20 rounded text-xs">
                            Delivery
                          </span>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>

        {/* Tomorrow */}
        <div className="bg-zinc-900 border border-zinc-800 rounded-xl p-4">
          <h3 className="text-lg font-semibold text-white mb-3">Tomorrow</h3>
          {getOrdersForDate(1).length === 0 ? (
            <p className="text-zinc-500 text-sm">No orders for tomorrow</p>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="text-left text-zinc-500 border-b border-zinc-800">
                    <th className="pb-2 font-medium">Order No</th>
                    <th className="pb-2 font-medium">Customer</th>
                    <th className="pb-2 font-medium">Service</th>
                    <th className="pb-2 font-medium">Type</th>
                  </tr>
                </thead>
                <tbody>
                  {getOrdersForDate(1).map((order) => (
                    <tr key={order.id} className="border-b border-zinc-800/50">
                      <td className="py-2 text-white">{order.orderNo || order.id}</td>
                      <td className="py-2 text-zinc-300">{getCustomerName(order.customerId)}</td>
                      <td className="py-2 text-zinc-300">{order.service}</td>
                      <td className="py-2">
                        {isDateMatch(order.trialDate, getDateForDay(1)) && (
                          <span className="inline-block px-2 py-0.5 bg-slate-500/10 text-slate-400 border border-slate-500/20 rounded text-xs mr-1">
                            Trial
                          </span>
                        )}
                        {isDateMatch(order.deliveryDate, getDateForDay(1)) && (
                          <span className="inline-block px-2 py-0.5 bg-green-500/10 text-green-400 border border-green-500/20 rounded text-xs">
                            Delivery
                          </span>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>

        {/* Day After Tomorrow */}
        <div className="bg-zinc-900 border border-zinc-800 rounded-xl p-4">
          <h3 className="text-lg font-semibold text-white mb-3">
            {(() => {
              const date = new Date();
              date.setDate(date.getDate() + 2);
              const day = String(date.getDate()).padStart(2, '0');
              const month = String(date.getMonth() + 1).padStart(2, '0');
              const year = date.getFullYear();
              return `${day}.${month}.${year}`;
            })()}
          </h3>
          {getOrdersForDate(2).length === 0 ? (
            <p className="text-zinc-500 text-sm">No orders</p>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="text-left text-zinc-500 border-b border-zinc-800">
                    <th className="pb-2 font-medium">Order No</th>
                    <th className="pb-2 font-medium">Customer</th>
                    <th className="pb-2 font-medium">Service</th>
                    <th className="pb-2 font-medium">Type</th>
                  </tr>
                </thead>
                <tbody>
                  {getOrdersForDate(2).map((order) => (
                    <tr key={order.id} className="border-b border-zinc-800/50">
                      <td className="py-2 text-white">{order.orderNo || order.id}</td>
                      <td className="py-2 text-zinc-300">{getCustomerName(order.customerId)}</td>
                      <td className="py-2 text-zinc-300">{order.service}</td>
                      <td className="py-2">
                        {isDateMatch(order.trialDate, getDateForDay(2)) && (
                          <span className="inline-block px-2 py-0.5 bg-slate-500/10 text-slate-400 border border-slate-500/20 rounded text-xs mr-1">
                            Trial
                          </span>
                        )}
                        {isDateMatch(order.deliveryDate, getDateForDay(2)) && (
                          <span className="inline-block px-2 py-0.5 bg-green-500/10 text-green-400 border border-green-500/20 rounded text-xs">
                            Delivery
                          </span>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>

      {/* Create Appointment Modal */}
      {showModal && (
        <div className="fixed inset-0 bg-black/60 flex items-center justify-center z-50 p-4">
          <div className="bg-zinc-900 border border-zinc-800 rounded-2xl w-full max-w-md">
            <div className="flex items-center justify-between p-5 border-b border-zinc-800">
              <h2 className="text-lg font-semibold text-white">New Appointment</h2>
              <button onClick={() => setShowModal(false)} className="text-zinc-400 hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>
            <form onSubmit={handleSubmit} className="p-5 space-y-4">
              <div>
                <label className="block text-sm text-zinc-400 mb-1.5">Date</label>
                <div className="bg-zinc-800 border border-zinc-700 rounded-lg px-3 py-2.5 text-white text-sm">
                  {selectedDate}
                </div>
                <input type="hidden" value={selectedDate} />
              </div>
              <div>
                <label className="block text-sm text-zinc-400 mb-1.5">Time</label>
                <select
                  value={formData.time}
                  onChange={(e) => setFormData({ ...formData, time: e.target.value })}
                  className="w-full bg-zinc-800 border border-zinc-700 rounded-lg px-3 py-2.5 text-white text-sm focus:outline-none focus:border-primary"
                  required
                >
                  <option value="">Select time</option>
                  {TIME_SLOTS.map((slot) => (
                    <option key={slot} value={slot}>{slot}</option>
                  ))}
                </select>
              </div>
              <div>
                <label className="block text-sm text-zinc-400 mb-1.5">Customer</label>
                <select
                  value={formData.customer}
                  onChange={(e) => setFormData({ ...formData, customer: e.target.value })}
                  className="w-full bg-zinc-800 border border-zinc-700 rounded-lg px-3 py-2.5 text-white text-sm focus:outline-none focus:border-primary"
                  required
                >
                  <option value="">Select customer</option>
                  {customers.map((c) => (
                    <option key={c.id} value={c.name}>{c.name}</option>
                  ))}
                </select>
              </div>
              <div>
                <label className="block text-sm text-zinc-400 mb-1.5">Service</label>
                <input
                  type="text"
                  value={formData.service}
                  onChange={(e) => setFormData({ ...formData, service: e.target.value })}
                  placeholder="e.g., Suit Alteration"
                  className="w-full bg-zinc-800 border border-zinc-700 rounded-lg px-3 py-2.5 text-white text-sm focus:outline-none focus:border-primary"
                  required
                />
              </div>
              <div>
                <label className="block text-sm text-zinc-400 mb-1.5">Appointment Type</label>
                <select
                  value={formData.type}
                  onChange={(e) => setFormData({ ...formData, type: e.target.value })}
                  className="w-full bg-zinc-800 border border-zinc-700 rounded-lg px-3 py-2.5 text-white text-sm focus:outline-none focus:border-primary"
                  required
                >
                  <option value="">Select type</option>
                  {APPOINTMENT_TYPES.map((type) => (
                    <option key={type} value={type}>{type}</option>
                  ))}
                </select>
              </div>
              <div className="pt-2">
                <button
                  type="submit"
                  disabled={saving}
                  className="w-full bg-primary hover:bg-primary disabled:opacity-50 text-white py-2.5 rounded-lg text-sm font-medium transition-colors"
                >
                  {saving ? "Creating..." : "Create Appointment"}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Selected Date Orders Panel */}
      {showOrdersPanel && selectedDateOrders && (
        <div className="fixed inset-0 bg-black/60 flex items-center justify-center z-50 p-4">
          <div className="bg-zinc-900 border border-zinc-800 rounded-2xl w-full max-w-lg max-h-[80vh] overflow-hidden">
            <div className="flex items-center justify-between p-5 border-b border-zinc-800">
              <div>
                <h2 className="text-lg font-semibold text-white">{selectedDateOrders.date}</h2>
                <p className="text-sm text-zinc-400 mt-0.5">Trial and Delivery Orders</p>
              </div>
              <button 
                onClick={() => {
                  setShowOrdersPanel(false);
                  setSelectedDateOrders(null);
                }} 
                className="text-zinc-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            <div className="p-5 overflow-y-auto max-h-[60vh]">
              {selectedDateOrders.orders.length === 0 ? (
                <p className="text-zinc-500 text-sm">No Trial or Delivery orders for this date</p>
              ) : (
                <div className="space-y-3">
                  {selectedDateOrders.orders.map((order) => {
                    const isTrial = isDateMatch(order.trialDate, parseSelectedDate(selectedDateOrders.date));
                    const isDelivery = isDateMatch(order.deliveryDate, parseSelectedDate(selectedDateOrders.date));
                    return (
                      <div key={order.id} className="bg-zinc-800 border border-zinc-700 rounded-lg p-4">
                        <div className="flex items-center gap-2 mb-2">
                          {isTrial && (
                            <span className="px-3 py-1 bg-slate-500/10 text-slate-400 border border-slate-500/20 rounded text-xs font-medium">
                              Trial: {order.orderNo || order.id}
                            </span>
                          )}
                          {isDelivery && (
                            <span className="px-3 py-1 bg-green-500/10 text-green-400 border border-green-500/20 rounded text-xs font-medium">
                              Delivery: {order.orderNo || order.id}
                            </span>
                          )}
                        </div>
                        <div className="text-sm text-zinc-300">
                          <span className="flex items-center gap-1.5">
                            <User className="w-3.5 h-3.5 text-zinc-500" />
                            {getCustomerName(order.customerId)}
                          </span>
                        </div>
                        <div className="mt-1 text-sm text-zinc-400">
                          <span className="flex items-center gap-1.5">
                            <Tag className="w-3.5 h-3.5 text-zinc-500" />
                            {order.service}
                          </span>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
