import type { Metadata, Viewport } from "next";
import "./globals.css";
import TopNav from "@/components/TopNav";
import { AppProvider } from "@/lib/context";

export const metadata: Metadata = {
  title: "TailorTracker",
  description: "Tailor shop management system",
};

export const viewport: Viewport = {
  width: "device-width",
  initialScale: 1,
  maximumScale: 1,
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <body className="bg-zinc-950 text-zinc-100 min-h-screen">
        <AppProvider>
          <TopNav />
          <main className="flex-1 overflow-auto pt-16">
            {children}
          </main>
        </AppProvider>
      </body>
    </html>
  );
}
