"use client";

import { useState } from "react";
import { Store, Clock, Palette, User, Check } from "lucide-react";
import { useApp } from "@/lib/context";

const tabs = [
  { id: "profile", label: "Shop Profile", icon: Store },
  { id: "hours", label: "Shop Hours", icon: Clock },
  { id: "branding", label: "Branding", icon: Palette },
  { id: "account", label: "Account Settings", icon: User },
];

const days = ["Sat", "Sun", "Mon", "Tue", "Wed", "Thu", "Fri"];

export default function SettingsPage() {
  const { isAdmin } = useApp();
  const [activeTab, setActiveTab] = useState("profile");
  const [saved, setSaved] = useState(false);

  const [profile, setProfile] = useState({
    shopName: "Raymond Gallery",
    ownerName: "Md. Khasruzzaman",
    email: "",
    phone: "+8801325682009",
    address: "103/104 Shahbag Market, Beside Al Marzan Shopping Center, Zindabazar, Sylhet.",
    description: "Premium bespoke tailoring services",
    acceptingFittings: true,
  });

  const [hours, setHours] = useState(
    days.map((day) => ({
      day,
      open: day !== "Fri",
      from: "10:30",
      to: "21:30",
    }))
  );

  const [branding, setBranding] = useState({
    primaryColor: "#6366f1",
    accentColor: "#8b5cf6",
    logoText: "TailorTrack",
  });

  const [account, setAccount] = useState({
    name: "John Doe",
    email: "john@tailortrack.com",
    currentPassword: "",
    newPassword: "",
    confirmPassword: "",
  });

  const handleSave = () => {
    setSaved(true);
    setTimeout(() => setSaved(false), 2000);
  };

  return (
    <div className="p-4 md:p-8">
      {/* Header */}
      <div className="mb-8">
        <h1 className="text-2xl font-bold text-white">Settings</h1>
        <p className="text-zinc-400 text-sm mt-1">
          Manage your shop preferences and account settings
        </p>
      </div>

      <div className="flex gap-6">
        {/* Sidebar Tabs */}
        <div className="w-56 flex-shrink-0">
          <div className="bg-zinc-900 border border-zinc-800 rounded-xl p-2 space-y-1">
            {tabs.map(({ id, label, icon: Icon }) => (
              <button
                key={id}
                onClick={() => setActiveTab(id)}
                className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-colors text-left ${
                  activeTab === id
                    ? "bg-primary text-white"
                    : "text-zinc-400 hover:text-white hover:bg-zinc-800"
                }`}
              >
                <Icon className="w-4 h-4" />
                {label}
              </button>
            ))}
          </div>
        </div>

        {/* Content */}
        <div className="flex-1">
          {/* Shop Profile */}
          {activeTab === "profile" && (
            <div className="bg-zinc-900 border border-zinc-800 rounded-xl p-6">
              <h2 className="text-lg font-semibold text-white mb-6">
                Shop Profile
              </h2>
              <div className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-medium text-zinc-400 mb-1.5">
                      Shop Name
                    </label>
                    <input
                      type="text"
                      value={profile.shopName}
                      onChange={(e) =>
                        setProfile({ ...profile, shopName: e.target.value })
                      }
                      className="w-full bg-zinc-800 border border-zinc-700 text-white text-sm rounded-lg px-3 py-2.5 focus:outline-none focus:border-primary"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-zinc-400 mb-1.5">
                      Owner Name
                    </label>
                    <input
                      type="text"
                      value={profile.ownerName}
                      onChange={(e) =>
                        setProfile({ ...profile, ownerName: e.target.value })
                      }
                      className="w-full bg-zinc-800 border border-zinc-700 text-white text-sm rounded-lg px-3 py-2.5 focus:outline-none focus:border-primary"
                    />
                  </div>
                </div>
                <div>
                  <label className="block text-xs font-medium text-zinc-400 mb-1.5">
                    Address
                  </label>
                  <input
                    type="text"
                    value={profile.address}
                    onChange={(e) =>
                      setProfile({ ...profile, address: e.target.value })
                    }
                    className="w-full bg-zinc-800 border border-zinc-700 text-white text-sm rounded-lg px-3 py-2.5 focus:outline-none focus:border-primary"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-zinc-400 mb-1.5">
                    Phone
                  </label>
                  <input
                    type="tel"
                    value={profile.phone}
                    onChange={(e) =>
                      setProfile({ ...profile, phone: e.target.value })
                    }
                    className="w-full bg-zinc-800 border border-zinc-700 text-white text-sm rounded-lg px-3 py-2.5 focus:outline-none focus:border-primary"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-zinc-400 mb-1.5">
                    Description
                  </label>
                  <textarea
                    value={profile.description}
                    onChange={(e) =>
                      setProfile({ ...profile, description: e.target.value })
                    }
                    rows={3}
                    className="w-full bg-zinc-800 border border-zinc-700 text-white text-sm rounded-lg px-3 py-2.5 focus:outline-none focus:border-primary resize-none"
                  />
                </div>
                <div className="flex items-center justify-between p-4 bg-zinc-800 rounded-lg">
                  <div>
                    <p className="text-sm font-medium text-white">
                      Currently Accepting New Fittings
                    </p>
                    <p className="text-xs text-zinc-500 mt-0.5">
                      Toggle to show availability status
                    </p>
                  </div>
                  <button
                    onClick={() =>
                      setProfile({
                        ...profile,
                        acceptingFittings: !profile.acceptingFittings,
                      })
                    }
                    className={`relative w-11 h-6 rounded-full transition-colors ${
                      profile.acceptingFittings
                        ? "bg-primary"
                        : "bg-zinc-600"
                    }`}
                  >
                    <span
                      className={`absolute top-0.5 left-0.5 w-5 h-5 bg-white rounded-full transition-transform ${
                        profile.acceptingFittings ? "translate-x-5" : ""
                      }`}
                    />
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* Shop Hours */}
          {activeTab === "hours" && (
            <div className="bg-zinc-900 border border-zinc-800 rounded-xl p-6">
              <h2 className="text-lg font-semibold text-white mb-6">
                Shop Hours
              </h2>
              <div className="space-y-3">
                {hours.map((h, i) => (
                  <div
                    key={h.day}
                    className="flex items-center gap-4 p-3 bg-zinc-800 rounded-lg"
                  >
                    <div className="w-10 text-sm font-medium text-zinc-300">
                      {h.day}
                    </div>
                    <button
                      onClick={() => {
                        const updated = [...hours];
                        updated[i] = { ...h, open: !h.open };
                        setHours(updated);
                      }}
                      className={`relative w-9 h-5 rounded-full transition-colors flex-shrink-0 ${
                        h.open ? "bg-primary" : "bg-zinc-600"
                      }`}
                    >
                      <span
                        className={`absolute top-0.5 left-0.5 w-4 h-4 bg-white rounded-full transition-transform ${
                          h.open ? "translate-x-4" : ""
                        }`}
                      />
                    </button>
                    {h.open ? (
                      <div className="flex items-center gap-2 flex-1">
                        <input
                          type="time"
                          value={h.from}
                          onChange={(e) => {
                            const updated = [...hours];
                            updated[i] = { ...h, from: e.target.value };
                            setHours(updated);
                          }}
                          className="bg-zinc-700 border border-zinc-600 text-white text-sm rounded-lg px-2 py-1.5 focus:outline-none focus:border-primary"
                        />
                        <span className="text-zinc-500 text-sm">to</span>
                        <input
                          type="time"
                          value={h.to}
                          onChange={(e) => {
                            const updated = [...hours];
                            updated[i] = { ...h, to: e.target.value };
                            setHours(updated);
                          }}
                          className="bg-zinc-700 border border-zinc-600 text-white text-sm rounded-lg px-2 py-1.5 focus:outline-none focus:border-primary"
                        />
                      </div>
                    ) : (
                      <span className="text-sm text-zinc-500">Closed</span>
                    )}
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Branding */}
          {activeTab === "branding" && (
            <div className="bg-zinc-900 border border-zinc-800 rounded-xl p-6">
              <h2 className="text-lg font-semibold text-white mb-6">
                Branding
              </h2>
              <div className="space-y-6">
                <div>
                  <label className="block text-xs font-medium text-zinc-400 mb-1.5">
                    Logo Text
                  </label>
                  <input
                    type="text"
                    value={branding.logoText}
                    onChange={(e) =>
                      setBranding({ ...branding, logoText: e.target.value })
                    }
                    className="w-full bg-zinc-800 border border-zinc-700 text-white text-sm rounded-lg px-3 py-2.5 focus:outline-none focus:border-primary"
                  />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-medium text-zinc-400 mb-1.5">
                      Primary Color
                    </label>
                    <div className="flex items-center gap-3">
                      <input
                        type="color"
                        value={branding.primaryColor}
                        onChange={(e) =>
                          setBranding({
                            ...branding,
                            primaryColor: e.target.value,
                          })
                        }
                        className="w-10 h-10 rounded-lg border border-zinc-700 cursor-pointer bg-transparent"
                      />
                      <input
                        type="text"
                        value={branding.primaryColor}
                        onChange={(e) =>
                          setBranding({
                            ...branding,
                            primaryColor: e.target.value,
                          })
                        }
                        className="flex-1 bg-zinc-800 border border-zinc-700 text-white text-sm rounded-lg px-3 py-2.5 focus:outline-none focus:border-primary"
                      />
                    </div>
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-zinc-400 mb-1.5">
                      Accent Color
                    </label>
                    <div className="flex items-center gap-3">
                      <input
                        type="color"
                        value={branding.accentColor}
                        onChange={(e) =>
                          setBranding({
                            ...branding,
                            accentColor: e.target.value,
                          })
                        }
                        className="w-10 h-10 rounded-lg border border-zinc-700 cursor-pointer bg-transparent"
                      />
                      <input
                        type="text"
                        value={branding.accentColor}
                        onChange={(e) =>
                          setBranding({
                            ...branding,
                            accentColor: e.target.value,
                          })
                        }
                        className="flex-1 bg-zinc-800 border border-zinc-700 text-white text-sm rounded-lg px-3 py-2.5 focus:outline-none focus:border-primary"
                      />
                    </div>
                  </div>
                </div>
                {/* Preview */}
                <div className="p-4 bg-zinc-800 rounded-lg">
                  <p className="text-xs text-zinc-500 mb-3">Preview</p>
                  <div className="flex items-center gap-3">
                    <div
                      className="w-10 h-10 rounded-lg flex items-center justify-center"
                      style={{ backgroundColor: branding.primaryColor }}
                    >
                      <span className="text-white text-sm font-bold">
                        {branding.logoText.charAt(0)}
                      </span>
                    </div>
                    <span className="text-white font-bold">
                      {branding.logoText}
                    </span>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Account Settings */}
          {activeTab === "account" && (
            <div className="bg-zinc-900 border border-zinc-800 rounded-xl p-6">
              <h2 className="text-lg font-semibold text-white mb-6">
                Account Settings
              </h2>
              <div className="space-y-4">
                <div>
                  <label className="block text-xs font-medium text-zinc-400 mb-1.5">
                    Full Name
                  </label>
                  <input
                    type="text"
                    value={account.name}
                    onChange={(e) =>
                      setAccount({ ...account, name: e.target.value })
                    }
                    className="w-full bg-zinc-800 border border-zinc-700 text-white text-sm rounded-lg px-3 py-2.5 focus:outline-none focus:border-primary"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-zinc-400 mb-1.5">
                    Email
                  </label>
                  <input
                    type="email"
                    value={account.email}
                    onChange={(e) =>
                      setAccount({ ...account, email: e.target.value })
                    }
                    className="w-full bg-zinc-800 border border-zinc-700 text-white text-sm rounded-lg px-3 py-2.5 focus:outline-none focus:border-primary"
                  />
                </div>
                <div className="border-t border-zinc-800 pt-4">
                  <p className="text-sm font-medium text-white mb-4">
                    Change Password
                  </p>
                  <div className="space-y-3">
                    <div>
                      <label className="block text-xs font-medium text-zinc-400 mb-1.5">
                        Current Password
                      </label>
                      <input
                        type="password"
                        placeholder="••••••••"
                        value={account.currentPassword}
                        onChange={(e) =>
                          setAccount({
                            ...account,
                            currentPassword: e.target.value,
                          })
                        }
                        className="w-full bg-zinc-800 border border-zinc-700 text-white text-sm rounded-lg px-3 py-2.5 focus:outline-none focus:border-primary placeholder-zinc-600"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-medium text-zinc-400 mb-1.5">
                        New Password
                      </label>
                      <input
                        type="password"
                        placeholder="••••••••"
                        value={account.newPassword}
                        onChange={(e) =>
                          setAccount({
                            ...account,
                            newPassword: e.target.value,
                          })
                        }
                        className="w-full bg-zinc-800 border border-zinc-700 text-white text-sm rounded-lg px-3 py-2.5 focus:outline-none focus:border-primary placeholder-zinc-600"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-medium text-zinc-400 mb-1.5">
                        Confirm Password
                      </label>
                      <input
                        type="password"
                        placeholder="••••••••"
                        value={account.confirmPassword}
                        onChange={(e) =>
                          setAccount({
                            ...account,
                            confirmPassword: e.target.value,
                          })
                        }
                        className="w-full bg-zinc-800 border border-zinc-700 text-white text-sm rounded-lg px-3 py-2.5 focus:outline-none focus:border-primary placeholder-zinc-600"
                      />
                    </div>
                  </div>
                </div>
                <div className="border-t border-zinc-800 pt-4">
                  <div className="flex items-center justify-between p-4 bg-zinc-800 rounded-lg">
                    <div>
                      <p className="text-sm font-medium text-white">
                        Communications
                      </p>
                      <p className="text-xs text-zinc-500 mt-0.5">
                        Receive email notifications
                      </p>
                    </div>
                    <button className="relative w-11 h-6 rounded-full bg-primary transition-colors">
                      <span className="absolute top-0.5 left-0.5 w-5 h-5 bg-white rounded-full translate-x-5" />
                    </button>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Save Button */}
          {isAdmin && (
            <div className="mt-4 flex justify-end">
              <button
                onClick={handleSave}
                className={`flex items-center gap-2 px-6 py-2.5 rounded-lg text-sm font-medium transition-all ${
                  saved
                    ? "bg-green-600 text-white"
                    : "bg-primary hover:bg-primary text-white"
                }`}
              >
                {saved ? (
                  <>
                    <Check className="w-4 h-4" />
                    Saved!
                  </>
                ) : (
                  "Save Changes"
                )}
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
