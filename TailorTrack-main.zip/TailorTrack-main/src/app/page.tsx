"use client";

import { useApp } from "@/lib/context";
import {
  ShoppingBag,
  Users,
  TrendingUp,
  CheckCircle,
  Clock,
  ArrowUpRight,
  Calendar,
} from "lucide-react";
import Link from "next/link";

function StatusBadge({ status }: { status: string }) {
  const styles: Record<string, string> = {
    Pending: "bg-yellow-500/10 text-yellow-400 border border-yellow-500/20",
    "In Progress": "bg-blue-500/10 text-blue-400 border border-blue-500/20",
    Completed: "bg-green-500/10 text-green-400 border border-green-500/20",
  };
  return (
    <span
      className={`inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium ${styles[status] || "bg-zinc-700 text-zinc-300"}`}
    >
      {status}
    </span>
  );
}

export default function DashboardPage() {
  const { customers, orders, appointments } = useApp();

  const activeOrders = orders.filter((o) => o.status !== "Completed").length;
  const completedOrders = orders.filter((o) => o.status === "Completed").length;
  const totalRevenue = orders.reduce((sum, o) => sum + parseFloat(o.price || "0"), 0);
  const recentOrders = orders.slice(-5).reverse();
  const todayAppointments = appointments.filter((a) => a.date === "Today");

  const stats = [
    {
      label: "Active Orders",
      value: activeOrders.toString(),
      change: "+2",
      trending: "up",
      icon: ShoppingBag,
      color: "text-blue-400",
      bg: "bg-blue-500/10",
      border: "border-blue-500/20",
    },
    {
      label: "Total Customers",
      value: customers.length.toString(),
      change: "+1",
      trending: "up",
      icon: Users,
      color: "text-purple-400",
      bg: "bg-purple-500/10",
      border: "border-purple-500/20",
    },
    {
      label: "Total Orders Fulfilled",
      value: completedOrders.toString(),
      change: "+3",
      trending: "up",
      icon: CheckCircle,
      color: "text-green-400",
      bg: "bg-green-500/10",
      border: "border-green-500/20",
    },
    {
      label: "Total Revenue",
      value: `$${totalRevenue.toFixed(0)}`,
      change: "+12%",
      trending: "up",
      icon: TrendingUp,
      color: "text-slate-400",
      bg: "bg-slate-500/10",
      border: "border-slate-500/20",
    },
  ];

  const monthlyGoal = 20;
  const monthlyProgress = Math.min((completedOrders / monthlyGoal) * 100, 100);

  return (
    <div className="p-4 md:p-8">
      {/* Header */}
      <div className="mb-8">
        <h1 className="text-2xl font-bold text-white">Dashboard Overview</h1>
        <p className="text-zinc-400 text-sm mt-1">
          Welcome back, Raymond Gallery. Here&apos;s what&apos;s happening today.
        </p>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-4 mb-8">
        {stats.map((stat) => {
          const Icon = stat.icon;
          return (
            <div
              key={stat.label}
              className="bg-zinc-900 border border-zinc-800 rounded-xl p-5"
            >
              <div className="flex items-start justify-between mb-4">
                <div
                  className={`w-10 h-10 ${stat.bg} border ${stat.border} rounded-lg flex items-center justify-center`}
                >
                  <Icon className={`w-5 h-5 ${stat.color}`} />
                </div>
                <span className="flex items-center gap-1 text-xs text-green-400 font-medium">
                  <ArrowUpRight className="w-3 h-3" />
                  {stat.change}
                </span>
              </div>
              <p className="text-2xl font-bold text-white">{stat.value}</p>
              <p className="text-zinc-400 text-sm mt-1">{stat.label}</p>
            </div>
          );
        })}
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-3 gap-6">
        {/* Recent Orders */}
        <div className="xl:col-span-2 bg-zinc-900 border border-zinc-800 rounded-xl">
          <div className="flex items-center justify-between p-5 border-b border-zinc-800">
            <h2 className="font-semibold text-white">Recent Orders</h2>
            <Link
              href="/orders"
              className="text-xs text-primary-light hover:text-emerald-300 transition-colors"
            >
              View all
            </Link>
          </div>
          <div className="divide-y divide-zinc-800">
            {recentOrders.map((order) => {
              const customer = customers.find((c) => c.id === order.customerId);
              return (
                <div
                  key={order.id}
                  className="flex items-center justify-between px-5 py-3.5"
                >
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 bg-zinc-800 rounded-full flex items-center justify-center">
                      <span className="text-xs font-bold text-zinc-300">
                        {customer?.name.split(" ").map((n) => n[0]).join("") || "?"}
                      </span>
                    </div>
                    <div>
                      <p className="text-sm font-medium text-white">
                        {customer?.name || "Unknown"}
                      </p>
                      <p className="text-xs text-zinc-500">{order.service}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-4">
                    <span className="text-sm font-semibold text-white">
                      ${order.price}
                    </span>
                    <StatusBadge status={order.status} />
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Right Column */}
        <div className="space-y-6">
          {/* Monthly Goal */}
          <div className="bg-zinc-900 border border-zinc-800 rounded-xl p-5">
            <h2 className="font-semibold text-white mb-1">Monthly Order Goal Progress</h2>
            <p className="text-xs text-zinc-500 mb-4">
              {completedOrders} of {monthlyGoal} orders completed
            </p>
            <div className="w-full bg-zinc-800 rounded-full h-2 mb-2">
              <div
                className="bg-primary h-2 rounded-full transition-all"
                style={{ width: `${monthlyProgress}%` }}
              />
            </div>
            <p className="text-xs text-zinc-500 text-right">
              {monthlyProgress.toFixed(0)}%
            </p>
          </div>

          {/* Shop Statistics */}
          <div className="bg-zinc-900 border border-zinc-800 rounded-xl p-5">
            <h2 className="font-semibold text-white mb-4">Shop Statistics</h2>
            <div className="space-y-3">
              <div className="flex justify-between items-center">
                <span className="text-sm text-zinc-400">Total Orders</span>
                <span className="text-sm font-semibold text-white">{orders.length}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-sm text-zinc-400">Pending</span>
                <span className="text-sm font-semibold text-yellow-400">
                  {orders.filter((o) => o.status === "Pending").length}
                </span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-sm text-zinc-400">In Progress</span>
                <span className="text-sm font-semibold text-blue-400">
                  {orders.filter((o) => o.status === "In Progress").length}
                </span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-sm text-zinc-400">Completed</span>
                <span className="text-sm font-semibold text-green-400">
                  {completedOrders}
                </span>
              </div>
            </div>
          </div>

          {/* Upcoming Today */}
          <div className="bg-zinc-900 border border-zinc-800 rounded-xl p-5">
            <div className="flex items-center justify-between mb-4">
              <h2 className="font-semibold text-white">Upcoming Today</h2>
              <Link
                href="/appointments"
                className="text-xs text-primary-light hover:text-emerald-300 transition-colors"
              >
                View all
              </Link>
            </div>
            <div className="space-y-3">
              {todayAppointments.map((apt) => (
                <div key={apt.id} className="flex items-start gap-3">
                  <div className="w-8 h-8 bg-primary-light/10 border border-primary/20 rounded-lg flex items-center justify-center flex-shrink-0">
                    <Clock className="w-4 h-4 text-primary-light" />
                  </div>
                  <div>
                    <p className="text-sm font-medium text-white">{apt.customer}</p>
                    <p className="text-xs text-zinc-500">
                      {apt.time} · {apt.type}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
