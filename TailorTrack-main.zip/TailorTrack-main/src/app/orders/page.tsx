"use client";

import { useState, useEffect, Suspense } from "react";
import { useApp } from "@/lib/context";
import { Order, OrderStatus, GARMENT_TYPES } from "@/lib/store";
import { Plus, Search, Trash2, X, Pencil, Check } from "lucide-react";
import { useSearchParams, useRouter } from "next/navigation";

// Garment types that require detailed measurements (upper body)
const MEASUREMENT_GARMENT_TYPES = [
  "Shirt",
  "Coat",
  "Waist Coat",
  "Overcoat",
  "Mujib Coat",
  "Prince Coat",
  "Sherwani",
  "Panjabi",
  "Sodria",
  "Tub",
  "Fotua",
  "Katua",
  "Safari",
  "Kabuli",
  "Apron",
];

// Garment types that require pants measurements (lower body)
const PANT_MEASUREMENT_GARMENT_TYPES = [
  "Pant",
  "Gabardine",
  "Jeans",
  "Payjama",
  "3 quarter",
];

function StatusBadge({ status }: { status: string }) {
  const styles: Record<string, string> = {
    Pending: "bg-yellow-500/10 text-yellow-400 border border-yellow-500/20",
    "In Progress": "bg-blue-500/10 text-blue-400 border border-blue-500/20",
    Completed: "bg-green-500/10 text-green-400 border border-green-500/20",
  };
  return (
    <span
      className={`inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium ${styles[status] || "bg-zinc-700 text-zinc-300"}`}
    >
      {status}
    </span>
  );
}

interface NewOrderForm {
  customerId: string;
  orderNo: string;
  service: string;
  quantity: string;
  price: string;
  status: OrderStatus;
  deliveryDate: string;
  trialDate: string;
  note: string;
  // Upper body measurement fields
  measurementLength: string;
  measurementBody1: string;
  measurementBody2: string;
  measurementBody3: string;
  measurementShoulder: string;
  measurementSleeves: string;
  measurementCuff: string;
  measurementCollar: string;
  measurementFront1: string;
  measurementFront2: string;
  measurementFront3: string;
  measurementBack1: string;
  measurementBack2: string;
  measurementBack3: string;
  measurementBiceps: string;
  measurementRadius: string;
  // Pants measurement fields
  pantLength: string;
  pantWaist: string;
  pantHip: string;
  pantThigh: string;
  pantMiddle1: string;
  pantMiddle2: string;
  pantQuarter: string;
  pantBottom: string;
  pantHigh: string;
  pantFront: string;
  pantBack: string;
}

const initialForm: NewOrderForm = {
  customerId: "",
  orderNo: "",
  service: "",
  quantity: "",
  price: "",
  status: "Pending",
  deliveryDate: "",
  trialDate: "",
  note: "",
  // Upper body measurement fields
  measurementLength: "",
  measurementBody1: "",
  measurementBody2: "",
  measurementBody3: "",
  measurementShoulder: "",
  measurementSleeves: "",
  measurementCuff: "",
  measurementCollar: "",
  measurementFront1: "",
  measurementFront2: "",
  measurementFront3: "",
  measurementBack1: "",
  measurementBack2: "",
  measurementBack3: "",
  measurementBiceps: "",
  measurementRadius: "",
  // Pants measurement fields
  pantLength: "",
  pantWaist: "",
  pantHip: "",
  pantThigh: "",
  pantMiddle1: "",
  pantMiddle2: "",
  pantQuarter: "",
  pantBottom: "",
  pantHigh: "",
  pantFront: "",
  pantBack: "",
};

function OrdersContent() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const { customers, orders, addOrder, updateOrder, deleteOrder, isAdmin } = useApp();
  const [search, setSearch] = useState("");
  const [showModal, setShowModal] = useState(false);
  const [form, setForm] = useState<NewOrderForm>(initialForm);
  const [editingOrder, setEditingOrder] = useState<Order | null>(null);

  const customerId = searchParams.get("customer");
  const showModalWithCustomer = customerId || showModal;
  const formWithCustomer = customerId && !showModal && !editingOrder 
    ? { ...initialForm, customerId } 
    : form;

  useEffect(() => {
    if (customerId && !showModal && !editingOrder) {
      // eslint-disable-next-line react-hooks/set-state-in-effect
      setForm({ ...initialForm, customerId });
      setShowModal(true);
      // Clear the URL parameter after opening modal
      router.replace("/orders");
    }
  }, [customerId, showModal, editingOrder]);

  const handleEdit = (order: Order) => {
    setEditingOrder(order);
    setForm({
      orderNo: order.orderNo || "",
      customerId: order.customerId,
      service: order.service,
      quantity: order.quantity,
      price: order.price,
      status: order.status,
      deliveryDate: order.deliveryDate,
      trialDate: order.trialDate,
      note: order.note,
      measurementLength: order.measurementLength,
      measurementBody1: order.measurementBody1,
      measurementBody2: order.measurementBody2,
      measurementBody3: order.measurementBody3,
      measurementShoulder: order.measurementShoulder,
      measurementSleeves: order.measurementSleeves,
      measurementCuff: order.measurementCuff,
      measurementCollar: order.measurementCollar,
      measurementFront1: order.measurementFront1,
      measurementFront2: order.measurementFront2,
      measurementFront3: order.measurementFront3,
      measurementBack1: order.measurementBack1,
      measurementBack2: order.measurementBack2,
      measurementBack3: order.measurementBack3,
      measurementBiceps: order.measurementBiceps,
      measurementRadius: order.measurementRadius,
      pantLength: order.pantLength || "",
      pantWaist: order.pantWaist || "",
      pantHip: order.pantHip || "",
      pantThigh: order.pantThigh || "",
      pantMiddle1: order.pantMiddle1 || "",
      pantMiddle2: order.pantMiddle2 || "",
      pantQuarter: order.pantQuarter || "",
      pantBottom: order.pantBottom || "",
      pantHigh: order.pantHigh || "",
      pantFront: order.pantFront || "",
      pantBack: order.pantBack || "",
    });
    setShowModal(true);
  };

  const showMeasurements = MEASUREMENT_GARMENT_TYPES.includes(form.service);
  const showPantMeasurements = PANT_MEASUREMENT_GARMENT_TYPES.includes(form.service);

  const filtered = orders
    .filter((o) => {
      const customer = customers.find((c) => c.id === o.customerId);
      const q = search.toLowerCase();
      return (
        o.id.toLowerCase().includes(q) ||
        o.service.toLowerCase().includes(q) ||
        o.status.toLowerCase().includes(q) ||
        (customer?.name || "").toLowerCase().includes(q)
      );
    })
    .sort((a, b) => {
      const statusOrder: Record<string, number> = {
        "Completed": 1,
        "In Progress": 2,
        "Pending": 3,
        "Delivered": 4
      };
      const aOrder = statusOrder[a.status] || 99;
      const bOrder = statusOrder[b.status] || 99;
      
      // First sort by status
      if (aOrder !== bOrder) return aOrder - bOrder;
      
      // Then sort by delivery date (most recent first within same status)
      if (a.deliveryDate && b.deliveryDate) {
        return new Date(b.deliveryDate).getTime() - new Date(a.deliveryDate).getTime();
      }
      // If only a has delivery date, it comes first
      if (a.deliveryDate && !b.deliveryDate) return -1;
      // If only b has delivery date, it comes first
      if (!a.deliveryDate && b.deliveryDate) return 1;
      // If neither has delivery date, keep original order
      return 0;
    });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.customerId || !form.service || !form.price) return;
    
    if (editingOrder) {
      updateOrder(editingOrder.id, form);
      setEditingOrder(null);
    } else {
      addOrder(form);
    }
    
    setForm(initialForm);
    setShowModal(false);
  };

  return (
    <div className="p-4 md:p-8">
      {/* Header */}
      <div className="flex items-center justify-between mb-8">
        <div>
          <h1 className="text-2xl font-bold text-white">Orders</h1>
          <p className="text-zinc-400 text-sm mt-1">
            Manage all your tailor orders
          </p>
        </div>
        {isAdmin && (
          <button
            onClick={() => { setEditingOrder(null); setForm(initialForm); setShowModal(true); }}
            className="flex items-center gap-2 bg-primary hover:bg-primary-hover text-white px-4 py-2 rounded-lg text-sm font-medium transition-all duration-300 glow-button"
          >
            <Plus className="w-4 h-4" />
            New Order
          </button>
        )}
      </div>

      {/* Search */}
      <div className="relative mb-6">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-zinc-500" />
        <input
          type="text"
          placeholder="Search orders..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          className="w-full bg-zinc-900 border border-zinc-800 rounded-lg pl-10 pr-4 py-2.5 text-sm text-white placeholder-zinc-500 focus:outline-none focus:border-primary transition-colors"
        />
      </div>

      {/* Table */}
      <div className="bg-zinc-900 border border-zinc-800 rounded-xl overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-zinc-800">
                <th className="text-left px-5 py-3.5 text-xs font-semibold text-zinc-500 uppercase tracking-wider">
                  Order ID
                </th>
                <th className="text-left px-5 py-3.5 text-xs font-semibold text-zinc-500 uppercase tracking-wider">
                  Customer
                </th>
                <th className="text-left px-5 py-3.5 text-xs font-semibold text-zinc-500 uppercase tracking-wider">
                  Service
                </th>
                <th className="text-left px-5 py-3.5 text-xs font-semibold text-zinc-500 uppercase tracking-wider">
                  Date
                </th>
                <th className="text-left px-5 py-3.5 text-xs font-semibold text-zinc-500 uppercase tracking-wider">
                  Delivery Date
                </th>
                <th className="text-left px-5 py-3.5 text-xs font-semibold text-zinc-500 uppercase tracking-wider">
                  Status
                </th>
                <th className="text-left px-5 py-3.5 text-xs font-semibold text-zinc-500 uppercase tracking-wider">
                  Price
                </th>
                <th className="text-left px-5 py-3.5 text-xs font-semibold text-zinc-500 uppercase tracking-wider">
                  Actions
                </th>
              </tr>
            </thead>
            <tbody className="divide-y divide-zinc-800">
              {filtered.length === 0 ? (
                <tr>
                  <td
                    colSpan={8}
                    className="text-center py-12 text-zinc-500 text-sm"
                  >
                    No orders found
                  </td>
                </tr>
              ) : (
                filtered.map((order) => {
                  const customer = customers.find(
                    (c) => c.id === order.customerId
                  );
                  return (
                    <tr key={order.id} className="hover:bg-zinc-800/50 transition-colors">
                      <td className="px-5 py-4 text-sm font-mono text-zinc-300">
                        {order.orderNo || order.id}
                      </td>
                      <td className="px-5 py-4">
                        <div className="flex items-center gap-2">
                          <div className="w-7 h-7 bg-zinc-800 rounded-full flex items-center justify-center">
                            <span className="text-xs font-bold text-zinc-300">
                              {customer?.name
                                .split(" ")
                                .map((n) => n[0])
                                .join("") || "?"}
                            </span>
                          </div>
                          <span className="text-sm text-white">
                            {customer?.name || "Unknown"}
                          </span>
                        </div>
                      </td>
                      <td className="px-5 py-4 text-sm text-zinc-300">
                        {order.service}
                      </td>
                      <td className="px-5 py-4 text-sm text-zinc-500">
                        {order.createdAt}
                      </td>
                      <td className="px-5 py-4 text-sm text-zinc-500">
                        {order.deliveryDate || "—"}
                      </td>
                      <td className="px-5 py-4">
                        <StatusBadge status={order.status} />
                      </td>
                      <td className="px-5 py-4 text-sm font-semibold text-white">
                        ${order.price}
                      </td>
                      <td className="px-5 py-4">
                        <div className="flex items-center gap-2">
                          <select
                            value={order.status}
                            onChange={(e) =>
                              updateOrder(order.id, {
                                status: e.target.value as OrderStatus,
                              })
                            }
                            className="bg-zinc-800 border border-zinc-700 text-zinc-300 text-xs rounded-lg px-2 py-1 focus:outline-none focus:border-primary"
                          >
                            <option value="Pending">Pending</option>
                            <option value="In Progress">In Progress</option>
                            <option value="Completed">Completed</option>
                            <option value="Delivered">Delivered</option>
                          </select>
                          {isAdmin && (
                            <button
                              onClick={() => handleEdit(order)}
                              className="text-zinc-500 hover:text-primary-light transition-colors"
                              title="Edit Order"
                            >
                              <Pencil className="w-4 h-4" />
                            </button>
                          )}
                          {isAdmin && (
                            <button
                              onClick={() => deleteOrder(order.id)}
                              className="text-zinc-500 hover:text-red-400 transition-colors"
                              title="Delete Order"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          )}
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
        <div className="px-5 py-3 border-t border-zinc-800 text-xs text-zinc-500">
          Showing {filtered.length} of {orders.length} orders
        </div>
      </div>

      {/* Create/Edit Order Modal */}
      {showModal && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-50 p-4">
          <div className="bg-zinc-900 border border-zinc-800 rounded-xl w-full max-w-2xl max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between p-5 border-b border-zinc-800 sticky top-0 bg-zinc-900 z-10">
              <h2 className="font-semibold text-white">{editingOrder ? "Edit Order" : "Create New Order"}</h2>
              <button
                onClick={() => { setShowModal(false); setEditingOrder(null); setForm(initialForm); }}
                className="text-zinc-500 hover:text-white transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            <form onSubmit={handleSubmit} className="p-5 space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-medium text-zinc-400 mb-1.5">
                    Select Customer
                  </label>
                  <select
                    value={form.customerId}
                    onChange={(e) =>
                      setForm({ ...form, customerId: e.target.value })
                    }
                    required
                    className="w-full bg-zinc-800 border border-zinc-700 text-white text-sm rounded-lg px-3 py-2.5 focus:outline-none focus:border-primary"
                  >
                    <option value="">Select a customer...</option>
                    {customers.map((c) => (
                      <option key={c.id} value={c.id}>
                        {c.name}
                      </option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-medium text-zinc-400 mb-1.5">
                    Order No
                  </label>
                  <input
                    type="text"
                    placeholder="ORD-001"
                    value={form.orderNo}
                    onChange={(e) => setForm({ ...form, orderNo: e.target.value })}
                    className="w-full bg-zinc-800 border border-zinc-700 text-white text-sm rounded-lg px-3 py-2.5 focus:outline-none focus:border-primary placeholder-zinc-600"
                  />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-medium text-zinc-400 mb-1.5">
                    Garment Type
                  </label>
                  <select
                    value={form.service}
                    onChange={(e) =>
                      setForm({ ...form, service: e.target.value })
                    }
                    required
                    className="w-full bg-zinc-800 border border-zinc-700 text-white text-sm rounded-lg px-3 py-2.5 focus:outline-none focus:border-primary"
                  >
                    <option value="">Select garment type...</option>
                    {GARMENT_TYPES.map((g) => (
                      <option key={g} value={g}>
                        {g}
                      </option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-medium text-zinc-400 mb-1.5">
                    Quantity
                  </label>
                  <input
                    type="text"
                    placeholder="1"
                    value={form.quantity}
                    onChange={(e) => setForm({ ...form, quantity: e.target.value })}
                    className="w-full bg-zinc-800 border border-zinc-700 text-white text-sm rounded-lg px-3 py-2.5 focus:outline-none focus:border-primary placeholder-zinc-600"
                  />
                </div>
              </div>
              <div>
                <label className="block text-xs font-medium text-zinc-400 mb-1.5">
                  Price ($)
                </label>
                <input
                  type="number"
                  placeholder="0.00"
                  value={form.price}
                  onChange={(e) => setForm({ ...form, price: e.target.value })}
                  required
                  className="w-full bg-zinc-800 border border-zinc-700 text-white text-sm rounded-lg px-3 py-2.5 focus:outline-none focus:border-primary placeholder-zinc-600"
                />
              </div>
              <div>
                <label className="block text-xs font-medium text-zinc-400 mb-1.5">
                  Initial Status
                </label>
                <select
                  value={form.status}
                  onChange={(e) =>
                    setForm({ ...form, status: e.target.value as OrderStatus })
                  }
                  className="w-full bg-zinc-800 border border-zinc-700 text-white text-sm rounded-lg px-3 py-2.5 focus:outline-none focus:border-primary"
                >
                  <option value="Pending">Pending</option>
                  <option value="In Progress">In Progress</option>
                  <option value="Completed">Completed</option>
                </select>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-medium text-zinc-400 mb-1.5">
                    Delivery Date
                  </label>
                  <input
                    type="date"
                    value={form.deliveryDate}
                    onChange={(e) => setForm({ ...form, deliveryDate: e.target.value })}
                    className="w-full bg-zinc-800 border border-zinc-700 text-white text-sm rounded-lg px-3 py-2.5 focus:outline-none focus:border-primary"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-zinc-400 mb-1.5">
                    Trial Date
                  </label>
                  <input
                    type="date"
                    value={form.trialDate}
                    onChange={(e) => setForm({ ...form, trialDate: e.target.value })}
                    className="w-full bg-zinc-800 border border-zinc-700 text-white text-sm rounded-lg px-3 py-2.5 focus:outline-none focus:border-primary"
                  />
                </div>
              </div>

              {/* Conditional Measurement Fields */}
              {showMeasurements && (
                <div className="border-t border-zinc-800 pt-4 mt-4">
                  <h3 className="text-sm font-medium text-white mb-4">Measurements</h3>
                  
                  {/* Length - 1 text box */}
                  <div className="mb-4">
                    <label className="block text-xs font-medium text-zinc-400 mb-1.5">
                      Length
                    </label>
                    <input
                      type="text"
                      placeholder="Length"
                      value={form.measurementLength}
                      onChange={(e) => setForm({ ...form, measurementLength: e.target.value })}
                      className="w-full bg-zinc-800 border border-zinc-700 text-white text-sm rounded-lg px-3 py-2 focus:outline-none focus:border-primary placeholder-zinc-600"
                    />
                  </div>

                  {/* Body - 3 text boxes */}
                  <div className="grid grid-cols-3 gap-3 mb-4">
                    <div>
                      <label className="block text-xs font-medium text-zinc-400 mb-1.5">
                        Chest
                      </label>
                      <input
                        type="text"
                        placeholder="Chest"
                        value={form.measurementBody1}
                        onChange={(e) => setForm({ ...form, measurementBody1: e.target.value })}
                        className="w-full bg-zinc-800 border border-zinc-700 text-white text-sm rounded-lg px-3 py-2 focus:outline-none focus:border-primary placeholder-zinc-600"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-medium text-zinc-400 mb-1.5">
                        Waist
                      </label>
                      <input
                        type="text"
                        placeholder="Waist"
                        value={form.measurementBody2}
                        onChange={(e) => setForm({ ...form, measurementBody2: e.target.value })}
                        className="w-full bg-zinc-800 border border-zinc-700 text-white text-sm rounded-lg px-3 py-2 focus:outline-none focus:border-primary placeholder-zinc-600"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-medium text-zinc-400 mb-1.5">
                        Bottom
                      </label>
                      <input
                        type="text"
                        placeholder="Bottom"
                        value={form.measurementBody3}
                        onChange={(e) => setForm({ ...form, measurementBody3: e.target.value })}
                        className="w-full bg-zinc-800 border border-zinc-700 text-white text-sm rounded-lg px-3 py-2 focus:outline-none focus:border-primary placeholder-zinc-600"
                      />
                    </div>
                  </div>

                  {/* Shoulder - 1 text box */}
                  <div className="mb-4">
                    <label className="block text-xs font-medium text-zinc-400 mb-1.5">
                      Shoulder
                    </label>
                    <input
                      type="text"
                      placeholder="Shoulder"
                      value={form.measurementShoulder}
                      onChange={(e) => setForm({ ...form, measurementShoulder: e.target.value })}
                      className="w-full bg-zinc-800 border border-zinc-700 text-white text-sm rounded-lg px-3 py-2 focus:outline-none focus:border-primary placeholder-zinc-600"
                    />
                  </div>

                  {/* Sleeves - 1 text box */}
                  <div className="mb-4">
                    <label className="block text-xs font-medium text-zinc-400 mb-1.5">
                      Sleeves
                    </label>
                    <input
                      type="text"
                      placeholder="Sleeves"
                      value={form.measurementSleeves}
                      onChange={(e) => setForm({ ...form, measurementSleeves: e.target.value })}
                      className="w-full bg-zinc-800 border border-zinc-700 text-white text-sm rounded-lg px-3 py-2 focus:outline-none focus:border-primary placeholder-zinc-600"
                    />
                  </div>

                  {/* Cuff - 1 text box */}
                  <div className="mb-4">
                    <label className="block text-xs font-medium text-zinc-400 mb-1.5">
                      Cuff
                    </label>
                    <input
                      type="text"
                      placeholder="Cuff"
                      value={form.measurementCuff}
                      onChange={(e) => setForm({ ...form, measurementCuff: e.target.value })}
                      className="w-full bg-zinc-800 border border-zinc-700 text-white text-sm rounded-lg px-3 py-2 focus:outline-none focus:border-primary placeholder-zinc-600"
                    />
                  </div>

                  {/* Collar - 1 text box */}
                  <div className="mb-4">
                    <label className="block text-xs font-medium text-zinc-400 mb-1.5">
                      Collar
                    </label>
                    <input
                      type="text"
                      placeholder="Collar"
                      value={form.measurementCollar}
                      onChange={(e) => setForm({ ...form, measurementCollar: e.target.value })}
                      className="w-full bg-zinc-800 border border-zinc-700 text-white text-sm rounded-lg px-3 py-2 focus:outline-none focus:border-primary placeholder-zinc-600"
                    />
                  </div>

                  {/* Front - 3 text boxes */}
                  <div className="grid grid-cols-3 gap-3 mb-4">
                    <div>
                      <label className="block text-xs font-medium text-zinc-400 mb-1.5">
                        Front 1
                      </label>
                      <input
                        type="text"
                        placeholder="Front 1"
                        value={form.measurementFront1}
                        onChange={(e) => setForm({ ...form, measurementFront1: e.target.value })}
                        className="w-full bg-zinc-800 border border-zinc-700 text-white text-sm rounded-lg px-3 py-2 focus:outline-none focus:border-primary placeholder-zinc-600"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-medium text-zinc-400 mb-1.5">
                        Front 2
                      </label>
                      <input
                        type="text"
                        placeholder="Front 2"
                        value={form.measurementFront2}
                        onChange={(e) => setForm({ ...form, measurementFront2: e.target.value })}
                        className="w-full bg-zinc-800 border border-zinc-700 text-white text-sm rounded-lg px-3 py-2 focus:outline-none focus:border-primary placeholder-zinc-600"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-medium text-zinc-400 mb-1.5">
                        Front 3
                      </label>
                      <input
                        type="text"
                        placeholder="Front 3"
                        value={form.measurementFront3}
                        onChange={(e) => setForm({ ...form, measurementFront3: e.target.value })}
                        className="w-full bg-zinc-800 border border-zinc-700 text-white text-sm rounded-lg px-3 py-2 focus:outline-none focus:border-primary placeholder-zinc-600"
                      />
                    </div>
                  </div>

                  {/* Back - 3 text boxes */}
                  <div className="grid grid-cols-3 gap-3 mb-4">
                    <div>
                      <label className="block text-xs font-medium text-zinc-400 mb-1.5">
                        Back 1
                      </label>
                      <input
                        type="text"
                        placeholder="Back 1"
                        value={form.measurementBack1}
                        onChange={(e) => setForm({ ...form, measurementBack1: e.target.value })}
                        className="w-full bg-zinc-800 border border-zinc-700 text-white text-sm rounded-lg px-3 py-2 focus:outline-none focus:border-primary placeholder-zinc-600"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-medium text-zinc-400 mb-1.5">
                        Back 2
                      </label>
                      <input
                        type="text"
                        placeholder="Back 2"
                        value={form.measurementBack2}
                        onChange={(e) => setForm({ ...form, measurementBack2: e.target.value })}
                        className="w-full bg-zinc-800 border border-zinc-700 text-white text-sm rounded-lg px-3 py-2 focus:outline-none focus:border-primary placeholder-zinc-600"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-medium text-zinc-400 mb-1.5">
                        Back 3
                      </label>
                      <input
                        type="text"
                        placeholder="Back 3"
                        value={form.measurementBack3}
                        onChange={(e) => setForm({ ...form, measurementBack3: e.target.value })}
                        className="w-full bg-zinc-800 border border-zinc-700 text-white text-sm rounded-lg px-3 py-2 focus:outline-none focus:border-primary placeholder-zinc-600"
                      />
                    </div>
                  </div>

                  {/* Biceps (M) - 1 text box */}
                  <div className="mb-4">
                    <label className="block text-xs font-medium text-zinc-400 mb-1.5">
                      Biceps (M)
                    </label>
                    <input
                      type="text"
                      placeholder="Biceps (M)"
                      value={form.measurementBiceps}
                      onChange={(e) => setForm({ ...form, measurementBiceps: e.target.value })}
                      className="w-full bg-zinc-800 border border-zinc-700 text-white text-sm rounded-lg px-3 py-2 focus:outline-none focus:border-primary placeholder-zinc-600"
                    />
                  </div>

                  {/* Radius (M) - 1 text box */}
                  <div className="mb-4">
                    <label className="block text-xs font-medium text-zinc-400 mb-1.5">
                      Radius (M)
                    </label>
                    <input
                      type="text"
                      placeholder="Radius (M)"
                      value={form.measurementRadius}
                      onChange={(e) => setForm({ ...form, measurementRadius: e.target.value })}
                      className="w-full bg-zinc-800 border border-zinc-700 text-white text-sm rounded-lg px-3 py-2 focus:outline-none focus:border-primary placeholder-zinc-600"
                    />
                  </div>
                </div>
              )}

              {/* Pants Measurement Fields */}
              {showPantMeasurements && (
                <div className="border-t border-zinc-800 pt-4 mt-4">
                  <h3 className="text-sm font-medium text-white mb-4">Pants Measurements</h3>
                  
                  {/* Length - 1 text box */}
                  <div className="mb-4">
                    <label className="block text-xs font-medium text-zinc-400 mb-1.5">
                      Length
                    </label>
                    <input
                      type="text"
                      placeholder="Length"
                      value={form.pantLength}
                      onChange={(e) => setForm({ ...form, pantLength: e.target.value })}
                      className="w-full bg-zinc-800 border border-zinc-700 text-white text-sm rounded-lg px-3 py-2 focus:outline-none focus:border-primary placeholder-zinc-600"
                    />
                  </div>

                  {/* Weist - 1 text box */}
                  <div className="mb-4">
                    <label className="block text-xs font-medium text-zinc-400 mb-1.5">
                      Weist
                    </label>
                    <input
                      type="text"
                      placeholder="Weist"
                      value={form.pantWaist}
                      onChange={(e) => setForm({ ...form, pantWaist: e.target.value })}
                      className="w-full bg-zinc-800 border border-zinc-700 text-white text-sm rounded-lg px-3 py-2 focus:outline-none focus:border-primary placeholder-zinc-600"
                    />
                  </div>

                  {/* Hip - 1 text box */}
                  <div className="mb-4">
                    <label className="block text-xs font-medium text-zinc-400 mb-1.5">
                      Hip
                    </label>
                    <input
                      type="text"
                      placeholder="Hip"
                      value={form.pantHip}
                      onChange={(e) => setForm({ ...form, pantHip: e.target.value })}
                      className="w-full bg-zinc-800 border border-zinc-700 text-white text-sm rounded-lg px-3 py-2 focus:outline-none focus:border-primary placeholder-zinc-600"
                    />
                  </div>

                  {/* Thigh - 1 text box */}
                  <div className="mb-4">
                    <label className="block text-xs font-medium text-zinc-400 mb-1.5">
                      Thigh
                    </label>
                    <input
                      type="text"
                      placeholder="Thigh"
                      value={form.pantThigh}
                      onChange={(e) => setForm({ ...form, pantThigh: e.target.value })}
                      className="w-full bg-zinc-800 border border-zinc-700 text-white text-sm rounded-lg px-3 py-2 focus:outline-none focus:border-primary placeholder-zinc-600"
                    />
                  </div>

                  {/* Middle - 2 text boxes */}
                  <div className="grid grid-cols-2 gap-3 mb-4">
                    <div>
                      <label className="block text-xs font-medium text-zinc-400 mb-1.5">
                        Middle 1
                      </label>
                      <input
                        type="text"
                        placeholder="Middle 1"
                        value={form.pantMiddle1}
                        onChange={(e) => setForm({ ...form, pantMiddle1: e.target.value })}
                        className="w-full bg-zinc-800 border border-zinc-700 text-white text-sm rounded-lg px-3 py-2 focus:outline-none focus:border-primary placeholder-zinc-600"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-medium text-zinc-400 mb-1.5">
                        Middle 2
                      </label>
                      <input
                        type="text"
                        placeholder="Middle 2"
                        value={form.pantMiddle2}
                        onChange={(e) => setForm({ ...form, pantMiddle2: e.target.value })}
                        className="w-full bg-zinc-800 border border-zinc-700 text-white text-sm rounded-lg px-3 py-2 focus:outline-none focus:border-primary placeholder-zinc-600"
                      />
                    </div>
                  </div>

                  {/* Quarter - 1 text box */}
                  <div className="mb-4">
                    <label className="block text-xs font-medium text-zinc-400 mb-1.5">
                      Quarter
                    </label>
                    <input
                      type="text"
                      placeholder="Quarter"
                      value={form.pantQuarter}
                      onChange={(e) => setForm({ ...form, pantQuarter: e.target.value })}
                      className="w-full bg-zinc-800 border border-zinc-700 text-white text-sm rounded-lg px-3 py-2 focus:outline-none focus:border-primary placeholder-zinc-600"
                    />
                  </div>

                  {/* Bottom - 1 text box */}
                  <div className="mb-4">
                    <label className="block text-xs font-medium text-zinc-400 mb-1.5">
                      Bottom
                    </label>
                    <input
                      type="text"
                      placeholder="Bottom"
                      value={form.pantBottom}
                      onChange={(e) => setForm({ ...form, pantBottom: e.target.value })}
                      className="w-full bg-zinc-800 border border-zinc-700 text-white text-sm rounded-lg px-3 py-2 focus:outline-none focus:border-primary placeholder-zinc-600"
                    />
                  </div>

                  {/* High - 1 text box */}
                  <div className="mb-4">
                    <label className="block text-xs font-medium text-zinc-400 mb-1.5">
                      High
                    </label>
                    <input
                      type="text"
                      placeholder="High"
                      value={form.pantHigh}
                      onChange={(e) => setForm({ ...form, pantHigh: e.target.value })}
                      className="w-full bg-zinc-800 border border-zinc-700 text-white text-sm rounded-lg px-3 py-2 focus:outline-none focus:border-primary placeholder-zinc-600"
                    />
                  </div>

                  {/* Front - 1 text box */}
                  <div className="mb-4">
                    <label className="block text-xs font-medium text-zinc-400 mb-1.5">
                      Front
                    </label>
                    <input
                      type="text"
                      placeholder="Front"
                      value={form.pantFront}
                      onChange={(e) => setForm({ ...form, pantFront: e.target.value })}
                      className="w-full bg-zinc-800 border border-zinc-700 text-white text-sm rounded-lg px-3 py-2 focus:outline-none focus:border-primary placeholder-zinc-600"
                    />
                  </div>

                  {/* Back - 1 text box */}
                  <div className="mb-4">
                    <label className="block text-xs font-medium text-zinc-400 mb-1.5">
                      Back
                    </label>
                    <input
                      type="text"
                      placeholder="Back"
                      value={form.pantBack}
                      onChange={(e) => setForm({ ...form, pantBack: e.target.value })}
                      className="w-full bg-zinc-800 border border-zinc-700 text-white text-sm rounded-lg px-3 py-2 focus:outline-none focus:border-primary placeholder-zinc-600"
                    />
                  </div>
                </div>
              )}

              <div>
                <label className="block text-xs font-medium text-zinc-400 mb-1.5">
                  Note
                </label>
                <textarea
                  placeholder="Add any special instructions..."
                  value={form.note}
                  onChange={(e) => setForm({ ...form, note: e.target.value })}
                  rows={3}
                  className="w-full bg-zinc-800 border border-zinc-700 text-white text-sm rounded-lg px-3 py-2 focus:outline-none focus:border-primary placeholder-zinc-600 resize-none"
                />
              </div>

              <div className="flex gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => setShowModal(false)}
                  className="flex-1 bg-zinc-800 hover:bg-zinc-700 text-zinc-300 px-4 py-2.5 rounded-lg text-sm font-medium transition-colors"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 bg-primary hover:bg-primary-hover text-white px-4 py-2.5 rounded-lg text-sm font-medium transition-all duration-300 glow-button"
                >
                  {editingOrder ? "Update Order" : "Create Order"}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}

export default function OrdersPage() {
  return (
    <Suspense fallback={<div className="p-8 text-white">Loading...</div>}>
      <OrdersContent />
    </Suspense>
  );
}
