import { sqliteTable, text, integer } from "drizzle-orm/sqlite-core";

export const customers = sqliteTable("customers", {
  id: text("id").primaryKey(),
  name: text("name").notNull(),
  email: text("email").notNull().default(""),
  phone: text("phone").notNull().default(""),
  address: text("address").notNull().default(""),
  notes: text("notes").notNull().default(""),
  lastVisit: text("last_visit").notNull().default(""),
  // Measurements stored as individual columns
  measurementChest: text("measurement_chest").notNull().default(""),
  measurementWaist: text("measurement_waist").notNull().default(""),
  measurementSleeve: text("measurement_sleeve").notNull().default(""),
  measurementShoulder: text("measurement_shoulder").notNull().default(""),
  measurementInseam: text("measurement_inseam").notNull().default(""),
});

export const orders = sqliteTable("orders", {
  id: text("id").primaryKey(),
  customerId: text("customer_id").notNull().references(() => customers.id),
  service: text("service").notNull(),
  quantity: text("quantity").notNull().default(""),
  price: text("price").notNull(),
  status: text("status", { enum: ["Pending", "In Progress", "Completed", "Delivered"] })
    .notNull()
    .default("Pending"),
  createdAt: text("created_at").notNull(),
  deliveryDate: text("delivery_date").notNull().default(""),
  trialDate: text("trial_date").notNull().default(""),
  note: text("note").notNull().default(""),
  // Upper body measurement fields
  measurementLength: text("measurement_length").notNull().default(""),
  measurementBody1: text("measurement_body_1").notNull().default(""),
  measurementBody2: text("measurement_body_2").notNull().default(""),
  measurementBody3: text("measurement_body_3").notNull().default(""),
  measurementShoulder: text("measurement_shoulder").notNull().default(""),
  measurementSleeves: text("measurement_sleeves").notNull().default(""),
  measurementCuff: text("measurement_cuff").notNull().default(""),
  measurementCollar: text("measurement_collar").notNull().default(""),
  measurementFront1: text("measurement_front_1").notNull().default(""),
  measurementFront2: text("measurement_front_2").notNull().default(""),
  measurementFront3: text("measurement_front_3").notNull().default(""),
  measurementBack1: text("measurement_back_1").notNull().default(""),
  measurementBack2: text("measurement_back_2").notNull().default(""),
  measurementBack3: text("measurement_back_3").notNull().default(""),
  measurementBiceps: text("measurement_biceps").notNull().default(""),
  measurementRadius: text("measurement_radius").notNull().default(""),
  // Pants measurement fields
  pantLength: text("pant_length").notNull().default(""),
  pantWaist: text("pant_waist").notNull().default(""),
  pantHip: text("pant_hip").notNull().default(""),
  pantThigh: text("pant_thigh").notNull().default(""),
  pantMiddle1: text("pant_middle_1").notNull().default(""),
  pantMiddle2: text("pant_middle_2").notNull().default(""),
  pantQuarter: text("pant_quarter").notNull().default(""),
  pantBottom: text("pant_bottom").notNull().default(""),
  pantHigh: text("pant_high").notNull().default(""),
  pantFront: text("pant_front").notNull().default(""),
  pantBack: text("pant_back").notNull().default(""),
});

export const appointments = sqliteTable("appointments", {
  id: text("id").primaryKey(),
  time: text("time").notNull(),
  customer: text("customer").notNull(),
  service: text("service").notNull(),
  type: text("type").notNull(),
  date: text("date").notNull(),
});
