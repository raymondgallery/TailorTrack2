CREATE TABLE `appointments` (
	`id` text PRIMARY KEY NOT NULL,
	`time` text NOT NULL,
	`customer` text NOT NULL,
	`service` text NOT NULL,
	`type` text NOT NULL,
	`date` text NOT NULL
);
--> statement-breakpoint
CREATE TABLE `customers` (
	`id` text PRIMARY KEY NOT NULL,
	`name` text NOT NULL,
	`email` text DEFAULT '' NOT NULL,
	`phone` text DEFAULT '' NOT NULL,
	`address` text DEFAULT '' NOT NULL,
	`notes` text DEFAULT '' NOT NULL,
	`last_visit` text DEFAULT '' NOT NULL,
	`measurement_chest` text DEFAULT '' NOT NULL,
	`measurement_waist` text DEFAULT '' NOT NULL,
	`measurement_sleeve` text DEFAULT '' NOT NULL,
	`measurement_shoulder` text DEFAULT '' NOT NULL,
	`measurement_inseam` text DEFAULT '' NOT NULL
);
--> statement-breakpoint
CREATE TABLE `orders` (
	`id` text PRIMARY KEY NOT NULL,
	`customer_id` text NOT NULL,
	`service` text NOT NULL,
	`price` text NOT NULL,
	`status` text DEFAULT 'Pending' NOT NULL,
	`created_at` text NOT NULL,
	FOREIGN KEY (`customer_id`) REFERENCES `customers`(`id`) ON UPDATE no action ON DELETE no action
);
