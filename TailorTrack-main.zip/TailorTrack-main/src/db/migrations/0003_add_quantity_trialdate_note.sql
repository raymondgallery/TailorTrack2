-- Add quantity, trial_date, and note columns to orders table
ALTER TABLE orders ADD COLUMN quantity text NOT NULL DEFAULT '';
ALTER TABLE orders ADD COLUMN trial_date text NOT NULL DEFAULT '';
ALTER TABLE orders ADD COLUMN note text NOT NULL DEFAULT '';
